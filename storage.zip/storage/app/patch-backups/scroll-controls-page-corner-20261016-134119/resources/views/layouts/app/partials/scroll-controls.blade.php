<style>
    .tesda-scroll-controls {
        position: relative;
        width: 100%;
        box-sizing: border-box;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        gap: .625rem;
        padding: 0 1rem .7rem;
        opacity: 0;
        visibility: hidden;
        pointer-events: none;
        transform: translateY(.35rem);
        transition: opacity .18s ease, transform .18s ease, visibility .18s ease;
    }

    .tesda-scroll-controls[data-visible="true"] {
        opacity: 1;
        visibility: visible;
        pointer-events: auto;
        transform: translateY(0);
    }

    .tesda-scroll-controls [hidden] {
        display: none !important;
    }

    .tesda-scroll-control {
        display: inline-flex;
        flex: 0 0 auto;
        width: 2.5rem;
        height: 2.5rem;
        align-items: center;
        justify-content: center;
        border: 1px solid rgba(255, 255, 255, .28);
        border-radius: 9999px;
        background: #102f68;
        color: #fff;
        box-shadow: 0 4px 12px rgba(15, 23, 42, .18);
        cursor: pointer;
        transition: background-color .15s ease, color .15s ease, transform .15s ease;
    }

    .tesda-scroll-control:hover {
        background: #0e7490;
        color: #fff;
        transform: translateY(-1px);
    }

    .tesda-scroll-control:focus-visible {
        outline: 3px solid #fbbf24;
        outline-offset: 3px;
    }

    @media (prefers-reduced-motion: reduce) {
        .tesda-scroll-controls,
        .tesda-scroll-control {
            transition: none;
        }
    }
</style>

<div class="tesda-scroll-controls" data-tesda-scroll-controls data-visible="false" aria-label="Page scroll controls">
    <button type="button" class="tesda-scroll-control" data-tesda-scroll-up hidden aria-label="Scroll up one screen" title="Scroll up">
        <flux:icon icon="arrow-up" class="size-5" />
    </button>
    <button type="button" class="tesda-scroll-control" data-tesda-scroll-down hidden aria-label="Scroll down one screen" title="Scroll down">
        <flux:icon icon="arrow-down" class="size-5" />
    </button>
</div>

<script>
    (() => {
        const globalKey = '__tesdaConnectScrollControlsV2';

        const update = () => {
            const controls = document.querySelector('[data-tesda-scroll-controls]');
            if (!controls) return;

            const root = document.documentElement;
            const scrollingElement = document.scrollingElement || root;
            const scrollTop = window.scrollY || scrollingElement.scrollTop || 0;
            const maxScroll = Math.max(0, scrollingElement.scrollHeight - window.innerHeight);
            const threshold = 80;
            const hasScrolled = scrollTop > threshold;
            const canScrollDown = maxScroll - scrollTop > threshold;

            controls.dataset.visible = hasScrolled ? 'true' : 'false';

            const up = controls.querySelector('[data-tesda-scroll-up]');
            const down = controls.querySelector('[data-tesda-scroll-down]');
            if (up) up.hidden = !hasScrolled;
            if (down) down.hidden = !hasScrolled || !canScrollDown;
        };

        if (!window[globalKey]) {
            let frame = null;

            const scheduleUpdate = () => {
                if (frame !== null) window.cancelAnimationFrame(frame);
                frame = window.requestAnimationFrame(() => {
                    frame = null;
                    update();
                });
            };

            window.addEventListener('scroll', scheduleUpdate, { passive: true });
            window.addEventListener('resize', scheduleUpdate, { passive: true });
            document.addEventListener('livewire:navigated', scheduleUpdate);
            document.addEventListener('click', (event) => {
                if (!(event.target instanceof Element)) return;
                const up = event.target.closest('[data-tesda-scroll-up]');
                const down = event.target.closest('[data-tesda-scroll-down]');
                if (!up && !down) return;

                const distance = Math.max(320, Math.round(window.innerHeight * 0.75));
                const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                window.scrollBy({
                    top: up ? -distance : distance,
                    behavior: reducedMotion ? 'auto' : 'smooth',
                });
            });

            window[globalKey] = true;
        }

        update();
        document.addEventListener('livewire:navigated', update);
    })();
</script>
