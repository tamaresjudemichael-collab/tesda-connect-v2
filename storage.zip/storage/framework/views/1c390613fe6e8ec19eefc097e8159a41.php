<?php
if (!function_exists('_1c390613fe6e8ec19eefc097e8159a41')):
function _1c390613fe6e8ec19eefc097e8159a41($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'tooltipPosition',
    'tooltipKbd',
    'tooltip',
]));
?>

<?php $tooltipPosition = $tooltipPosition ??= $attributes->pluck('tooltip:position'); ?>
<?php $tooltipKbd = $tooltipKbd ??= $attributes->pluck('tooltip:kbd'); ?>
<?php $tooltip = $tooltip ??= $attributes->pluck('tooltip'); ?>

<?php
$__defaults = [
    'tooltipPosition' => 'top',
    'tooltipKbd' => null,
    'tooltip' => null,
];
$tooltipPosition ??= $attributes['tooltip-position'] ?? $attributes['tooltipPosition'] ?? $__defaults['tooltipPosition']; unset($attributes['tooltipPosition'], $attributes['tooltip-position']);
$tooltipKbd ??= $attributes['tooltip-kbd'] ?? $attributes['tooltipKbd'] ?? $__defaults['tooltipKbd']; unset($attributes['tooltipKbd'], $attributes['tooltip-kbd']);
$tooltip ??= $attributes['tooltip'] ?? $__defaults['tooltip']; unset($attributes['tooltip']);
unset($__defaults);
?>

<?php if ($tooltip): ?>
    <?php if (!function_exists('_1c98d535edfbf583aa9b99f1d9c9094b')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php', $__blaze->compiledPath.'/1c98d535edfbf583aa9b99f1d9c9094b.php'); require $__blaze->compiledPath.'/1c98d535edfbf583aa9b99f1d9c9094b.php'; } ?>
<?php if (isset($__slots1c98d535edfbf583aa9b99f1d9c9094b)) { $__slotsStack1c98d535edfbf583aa9b99f1d9c9094b[] = $__slots1c98d535edfbf583aa9b99f1d9c9094b; } ?>
<?php if (isset($__attrs1c98d535edfbf583aa9b99f1d9c9094b)) { $__attrsStack1c98d535edfbf583aa9b99f1d9c9094b[] = $__attrs1c98d535edfbf583aa9b99f1d9c9094b; } ?>
<?php $__attrs1c98d535edfbf583aa9b99f1d9c9094b = ['class' => 'inline-flex','content' => $tooltip,'position' => $tooltipPosition,'kbd' => $tooltipKbd]; ?>
<?php $__slots1c98d535edfbf583aa9b99f1d9c9094b = []; ?>
<?php $__blaze->pushData($__attrs1c98d535edfbf583aa9b99f1d9c9094b); ?>
<?php ob_start(); ?>
        <?php echo e($slot); ?>

    <?php $__slots1c98d535edfbf583aa9b99f1d9c9094b['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots1c98d535edfbf583aa9b99f1d9c9094b); ?>
<?php _1c98d535edfbf583aa9b99f1d9c9094b($__blaze, $__attrs1c98d535edfbf583aa9b99f1d9c9094b, $__slots1c98d535edfbf583aa9b99f1d9c9094b, ['content', 'position', 'kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack1c98d535edfbf583aa9b99f1d9c9094b)) { $__slots1c98d535edfbf583aa9b99f1d9c9094b = array_pop($__slotsStack1c98d535edfbf583aa9b99f1d9c9094b); } ?>
<?php if (! empty($__attrsStack1c98d535edfbf583aa9b99f1d9c9094b)) { $__attrs1c98d535edfbf583aa9b99f1d9c9094b = array_pop($__attrsStack1c98d535edfbf583aa9b99f1d9c9094b); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/with-tooltip.blade.php ENDPATH**/ ?>