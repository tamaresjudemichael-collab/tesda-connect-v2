<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    public $formOpen;

    public $editingId;

    public $name;

    public $username;

    public $email;

    public $password;

    public $role;

    public $account_status;

    public $institutionIds;

    public function mount()
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    #[\Livewire\Attributes\Computed()]
    public function accounts()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('accounts'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function institutions()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('institutions'))->execute(...$arguments);
    }

    public function resetForm(): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('resetForm'))->execute(...$arguments);
    }

    public function openCreate(): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('openCreate'))->execute(...$arguments);
    }

    public function toggleInstitution(int $id): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('toggleInstitution'))->execute(...$arguments);
    }

    public function edit(int $id): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('edit'))->execute(...$arguments);
    }

    public function save(): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('save'))->execute(...$arguments);
    }

    public function delete(int $id): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('delete'))->execute(...$arguments);
    }

};