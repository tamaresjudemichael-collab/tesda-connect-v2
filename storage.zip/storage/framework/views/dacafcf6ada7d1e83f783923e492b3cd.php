<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    public $formOpen;

    public $editingId;

    public $institution_id;

    public $course_id;

    public $code;

    public $name;

    public $capacity;

    public $starts_at;

    public $ends_at;

    public $next_class_at;

    public $venue;

    public $status;

    public function mount()
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    #[\Livewire\Attributes\Computed()]
    public function institutionIds()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('institutionIds'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function institutions()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('institutions'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function courses()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('courses'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function batches()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('batches'))->execute(...$arguments);
    }

    public function resetForm(): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('resetForm'))->execute(...$arguments);
    }

    public function openCreate(): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('openCreate'))->execute(...$arguments);
    }

    public function updatedInstitutionId(): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('updatedInstitutionId'))->execute(...$arguments);
    }

    public function edit(int $id): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('edit'))->execute(...$arguments);
    }

    public function save(): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('save'))->execute(...$arguments);
    }

    public function delete(int $id): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('delete'))->execute(...$arguments);
    }

};