<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title>
    <?php echo e(filled($title ?? null) ? $title.' - '.config('app.name', 'Laravel') : config('app.name', 'Laravel')); ?>

</title>

<link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" sizes="any">
<link rel="icon" href="<?php echo e(asset('favicon.svg')); ?>" type="image/svg+xml">
<link rel="apple-touch-icon" href="<?php echo e(asset('apple-touch-icon.png')); ?>">
<link rel="manifest" href="<?php echo e(asset('manifest.webmanifest')); ?>">
<meta name="theme-color" content="#0f766e">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<script defer src="<?php echo e(asset('pwa-register.js')); ?>" data-worker-url="<?php echo e(asset('service-worker.js')); ?>" data-worker-scope="<?php echo e(url('/')); ?>"></script>
<script defer src="<?php echo e(asset('offline-competency-sync.js')); ?>" data-sync-url="<?php echo e(route('offline-sync.competency-progress')); ?>" data-user-id="<?php echo e(auth()->id() ?? ''); ?>"></script>

<?php echo app('Illuminate\Foundation\Vite')->fonts(); ?>

<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<script>
    document.documentElement.classList.remove('dark');
    document.documentElement.classList.add('light');
    localStorage.setItem('flux.appearance', 'light');
</script>
<?php echo app('flux')->fluxAppearance(); ?>

<?php /**PATH C:\xampp\htdocs\tesda-connect-v2\resources\views/partials/head.blade.php ENDPATH**/ ?>