<?php
if (!function_exists('_eb10117aa0aca7843ea7ed51fc0264b8')):
function _eb10117aa0aca7843ea7ed51fc0264b8($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'iconVariant' => 'mini',
    'size' => null,
];
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$size ??= $attributes['size'] ?? $__defaults['size']; unset($attributes['size']);
unset($__defaults);
?>

<?php
$attributes = $attributes->merge([
    'variant' => 'subtle',
    'class' => '-me-1',
    'square' => true,
    'size' => null,
]);
?>

<?php if (!function_exists('_454294d7e357cdd101c37b4ef6e737ae')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/454294d7e357cdd101c37b4ef6e737ae.php'); require $__blaze->compiledPath.'/454294d7e357cdd101c37b4ef6e737ae.php'; } ?>
<?php if (isset($__slots454294d7e357cdd101c37b4ef6e737ae)) { $__slotsStack454294d7e357cdd101c37b4ef6e737ae[] = $__slots454294d7e357cdd101c37b4ef6e737ae; } ?>
<?php if (isset($__attrs454294d7e357cdd101c37b4ef6e737ae)) { $__attrsStack454294d7e357cdd101c37b4ef6e737ae[] = $__attrs454294d7e357cdd101c37b4ef6e737ae; } ?>
<?php $__attrs454294d7e357cdd101c37b4ef6e737ae = ['attributes' => $attributes,'size' => $size === 'sm' || $size === 'xs' ? 'xs' : 'sm','xData' => 'fluxInputViewable','xOn:click' => 'toggle()','xBind:dataViewableOpen' => 'open','ariaLabel' => e(__('Toggle password visibility'))]; ?>
<?php $__slots454294d7e357cdd101c37b4ef6e737ae = []; ?>
<?php $__blaze->pushData($__attrs454294d7e357cdd101c37b4ef6e737ae); ?>
<?php ob_start(); ?>
    <?php if (!function_exists('_ac725b398bb3087e7fb161ff2cf8bfe3')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye-slash.blade.php', $__blaze->compiledPath.'/ac725b398bb3087e7fb161ff2cf8bfe3.php'); require $__blaze->compiledPath.'/ac725b398bb3087e7fb161ff2cf8bfe3.php'; } ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block']); ?>
<?php _ac725b398bb3087e7fb161ff2cf8bfe3($__blaze, ['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
    <?php if (!function_exists('_25606438bcf9a84232f2395151259e05')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye.blade.php', $__blaze->compiledPath.'/25606438bcf9a84232f2395151259e05.php'); require $__blaze->compiledPath.'/25606438bcf9a84232f2395151259e05.php'; } ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden']); ?>
<?php _25606438bcf9a84232f2395151259e05($__blaze, ['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
<?php $__slots454294d7e357cdd101c37b4ef6e737ae['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots454294d7e357cdd101c37b4ef6e737ae); ?>
<?php _454294d7e357cdd101c37b4ef6e737ae($__blaze, $__attrs454294d7e357cdd101c37b4ef6e737ae, $__slots454294d7e357cdd101c37b4ef6e737ae, ['attributes', 'size'], ['xData' => 'x-data', 'xOn:click' => 'x-on:click', 'xBind:dataViewableOpen' => 'x-bind:data-viewable-open', 'ariaLabel' => 'aria-label'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack454294d7e357cdd101c37b4ef6e737ae)) { $__slots454294d7e357cdd101c37b4ef6e737ae = array_pop($__slotsStack454294d7e357cdd101c37b4ef6e737ae); } ?>
<?php if (! empty($__attrsStack454294d7e357cdd101c37b4ef6e737ae)) { $__attrs454294d7e357cdd101c37b4ef6e737ae = array_pop($__attrsStack454294d7e357cdd101c37b4ef6e737ae); } ?>
<?php $__blaze->popData(); ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/input/viewable.blade.php ENDPATH**/ ?>