<?php # [BlazeFolded]:{flux::sidebar.collapse}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/collapse.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.header}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/header.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.nav}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/nav.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::spacer}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/spacer.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::icon}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::sidebar.toggle}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/toggle.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::spacer}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/spacer.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::header}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/header.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::toast}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/toast/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::toast.group}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/toast/group.blade.php}:{1790619293} ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <style>
            .tesda-sidebar {
                /* Wider desktop rail, but never wider than the available viewport. */
                --sidebar-width: 19rem;
                --sidebar-width-collapsed: 4.25rem;
                width: min(19rem, calc(100vw - 1rem)) !important;
                max-width: calc(100vw - 1rem) !important;
                min-width: 0;
                box-sizing: border-box;
                background-color: #102f68 !important;
                color: #ffffff !important;
                overflow-x: hidden !important;
            }

            .tesda-sidebar,
            .tesda-sidebar * {
                box-sizing: border-box;
            }

            /* Keep the vertical menu scrollable while eliminating the bottom horizontal bar. */
            .tesda-sidebar [data-flux-sidebar-nav],
            .tesda-sidebar [data-flux-sidebar-group] {
                min-width: 0 !important;
                max-width: 100% !important;
                overflow-x: hidden !important;
            }

            /* Only the main navigation should scroll; expandable groups must not create nested scrollbars. */
            .tesda-sidebar > [data-flux-sidebar-nav] {
                scrollbar-width: thin;
                scrollbar-color: rgba(191, 219, 254, 0.55) transparent;
                overscroll-behavior: contain;
            }

            /* Use the same typography for every role (administrator, registrar, focal person, learner). */
            .tesda-sidebar [data-flux-sidebar-item] {
                width: 100%;
                min-width: 0 !important;
                max-width: 100% !important;
                white-space: normal !important;
                font-size: 1rem !important;
                line-height: 1.35 !important;
                font-weight: 600;
            }

            .tesda-sidebar [data-flux-sidebar-item] > span:last-child {
                font-size: inherit !important;
            }

            /* Expandable and non-expandable group labels should have identical sizing. */
            .tesda-sidebar [data-flux-sidebar-group-heading],
            .tesda-sidebar [data-flux-sidebar-group] button[aria-expanded],
            .tesda-sidebar [data-flux-sidebar-group] [role="button"][aria-expanded] {
                font-size: 0.875rem !important;
                line-height: 1.3 !important;
                font-weight: 700 !important;
            }

            .tesda-sidebar [data-flux-sidebar-item] > span:last-child {
                flex: 1 1 auto;
                min-width: 0;
                max-width: 100%;
                white-space: normal !important;
                overflow-wrap: anywhere;
                line-height: 1.35;
            }

            .tesda-sidebar [data-flux-sidebar-item] > svg,
            .tesda-sidebar [data-flux-sidebar-item] > span:first-child:has(svg) {
                flex-shrink: 0;
            }

            .tesda-sidebar [data-flux-sidebar-group-heading] {
                max-width: 100%;
                white-space: normal !important;
                overflow-wrap: anywhere;
                line-height: 1.3;
            }

            .tesda-sidebar .tesda-disabled-nav {
                width: 100%;
                min-width: 0;
                max-width: 100%;
                flex-wrap: wrap;
                overflow-wrap: anywhere;
                font-size: 1rem !important;
                line-height: 1.35 !important;
                font-weight: 600;
            }

            .tesda-sidebar .tesda-disabled-nav > span:first-of-type {
                flex: 1 1 7rem;
                min-width: 0;
                overflow-wrap: anywhere;
                line-height: 1.35;
            }

            .tesda-sidebar .tesda-unavailable-label {
                flex: 0 1 auto;
                max-width: 100%;
                white-space: normal !important;
                overflow-wrap: anywhere;
                margin-left: auto;
            }

            @media (max-width: 640px) {
                .tesda-sidebar {
                    --sidebar-width: 18rem;
                    width: min(18rem, calc(100vw - 0.75rem)) !important;
                    max-width: calc(100vw - 0.75rem) !important;
                }

                .tesda-sidebar [data-flux-sidebar-nav] {
                    padding-inline: 0.5rem;
                }

                /* Do not shrink group labels on mobile; keep typography consistent across roles. */
                .tesda-sidebar [data-flux-sidebar-group-heading],
                .tesda-sidebar [data-flux-sidebar-group] button[aria-expanded],
                .tesda-sidebar [data-flux-sidebar-group] [role="button"][aria-expanded] {
                    font-size: 0.875rem !important;
                }

                .tesda-sidebar .tesda-disabled-nav {
                    gap: 0.5rem;
                    padding-inline: 0.625rem;
                }

                .tesda-sidebar .tesda-unavailable-label {
                    font-size: 0.625rem;
                }
            }

            .tesda-sidebar [data-flux-sidebar-item],
            .tesda-sidebar [data-flux-sidebar-item] > *,
            .tesda-sidebar [data-flux-sidebar-item] svg {
                color: #eaf2ff !important;
            }

            .tesda-sidebar [data-flux-sidebar-item]:hover {
                background-color: #ffffff !important;
                color: #102f68 !important;
            }

            .tesda-sidebar [data-flux-sidebar-item]:hover,
            .tesda-sidebar [data-flux-sidebar-item]:hover *,
            .tesda-sidebar [data-flux-sidebar-item]:hover svg {
                color: #102f68 !important;
            }

            .tesda-sidebar [data-flux-sidebar-item]:focus-visible {
                outline: 2px solid #ffffff !important;
                outline-offset: 2px;
            }

            .tesda-sidebar [data-flux-sidebar-item][data-current],
            .tesda-sidebar [data-flux-sidebar-item][aria-current="page"] {
                background-color: #ffffff !important;
                color: #102f68 !important;
                font-weight: 700 !important;
            }

            .tesda-sidebar [data-flux-sidebar-item][data-current] *,
            .tesda-sidebar [data-flux-sidebar-item][data-current] svg,
            .tesda-sidebar [data-flux-sidebar-item][aria-current="page"] *,
            .tesda-sidebar [data-flux-sidebar-item][aria-current="page"] svg {
                color: #102f68 !important;
            }

            .tesda-sidebar [data-flux-sidebar-group-heading] {
                color: #bfdbfe !important;
            }

            .tesda-sidebar .tesda-disabled-nav {
                color: rgba(234, 242, 255, 0.7) !important;
                cursor: not-allowed;
            }

            .tesda-sidebar .tesda-disabled-nav svg {
                color: rgba(191, 219, 254, 0.65) !important;
            }

            .tesda-sidebar .tesda-unavailable-label {
                color: #bfdbfe !important;
                font-size: 9px;
                line-height: 1.2;
                letter-spacing: 0.02em;
                white-space: nowrap;
            }

            .tesda-sidebar .tesda-nav-subheading {
                color: #bfdbfe !important;
                letter-spacing: 0.1em;
                text-transform: uppercase;
            }

            .tesda-sidebar a,
            .tesda-sidebar a span {
                color: inherit;
            }

            .tesda-sidebar .tesda-brand-name {
                color: #ffffff !important;
            }

            .tesda-sidebar .tesda-brand-accent {
                color: #f6a915 !important;
            }

            .tesda-sidebar .tesda-brand-subtitle {
                color: #bfdbfe !important;
            }

            .tesda-sidebar .tesda-user-name {
                color: #ffffff !important;
            }

            .tesda-sidebar .tesda-user-role {
                color: #bfdbfe !important;
            }

            .tesda-sidebar .tesda-logout {
                color: #ffffff !important;
            }

            .tesda-sidebar .tesda-logout:hover {
                background-color: rgba(255, 255, 255, 0.14) !important;
                color: #ffffff !important;
            }

            .tesda-sidebar .tesda-logout svg {
                color: inherit !important;
            }
        </style>
    </head>

    <body class="min-h-screen bg-slate-100 text-slate-900 antialiased">
        <?php ($user = auth()->user()); ?>

        <?php ob_start(); ?><ui-sidebar-toggle class="z-20 fixed inset-0 bg-black/10 hidden data-flux-sidebar-on-mobile:not-data-flux-sidebar-collapsed-mobile:block" data-flux-sidebar-backdrop></ui-sidebar-toggle>

<ui-sidebar
    class="[grid-area:sidebar] z-1 flex flex-col gap-4 [:where(&amp;)]:w-64 p-4 data-flux-sidebar-collapsed-desktop:w-14 data-flux-sidebar-collapsed-desktop:px-2 data-flux-sidebar-collapsed-desktop:cursor-e-resize rtl:data-flux-sidebar-collapsed-desktop:cursor-w-resize max-lg:data-flux-sidebar-cloak:hidden data-flux-sidebar-on-mobile:data-flux-sidebar-collapsed-mobile:-translate-x-full data-flux-sidebar-on-mobile:data-flux-sidebar-collapsed-mobile:rtl:translate-x-full z-20! data-flux-sidebar-on-mobile:start-0! data-flux-sidebar-on-mobile:fixed! data-flux-sidebar-on-mobile:top-0! data-flux-sidebar-on-mobile:min-h-dvh! data-flux-sidebar-on-mobile:max-h-dvh! max-h-dvh overflow-y-auto overscroll-contain tesda-sidebar border-e-0 shadow-xl shadow-slate-900/10" x-init="$el.classList.add(&#039;transition-transform&#039;)"
     collapsible="mobile"          sticky     x-data
    data-flux-sidebar-cloak
    data-flux-sidebar
>
    <?php ob_start(); ?>
            <?php ob_start(); ?><div class="flex items-center justify-between gap-2 min-h-10 border-b border-white/10 px-5 py-5" data-flux-sidebar-header>
    <?php ob_start(); ?>
                <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center gap-3" wire:navigate>
                    <span class="grid size-10 shrink-0 place-items-center rounded-full bg-white text-sm font-black text-[#102f68]">
                        TC
                    </span>

                    <span class="grid gap-0.5 leading-tight">
                        <span class="tesda-brand-name font-bold tracking-tight">
                            TESDA<span class="tesda-brand-accent">Connect</span>
                        </span>

                        <span class="tesda-brand-subtitle text-[11px]">
                            Training Operations
                        </span>
                    </span>
                </a>

                <?php ob_start(); ?><ui-sidebar-toggle class="w-10 h-8 shrink-0 flex items-center justify-center in-data-flux-sidebar-collapsed-desktop:opacity-0 in-data-flux-sidebar-collapsed-desktop:absolute in-data-flux-sidebar-collapsed-desktop:in-data-flux-sidebar-active:opacity-100  text-white lg:hidden" data-flux-sidebar-collapse>
    <ui-tooltip position="right center"  data-flux-tooltip >
        <button type="button" class="size-10 relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none text-sm rounded-lg inline-flex  bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white in-data-flux-sidebar-collapsed-desktop:cursor-e-resize rtl:in-data-flux-sidebar-collapsed-desktop:cursor-w-resize [&amp;[collapsible=&quot;mobile&quot;]]:in-data-flux-sidebar-on-desktop:hidden rtl:rotate-180">
            <svg class="text-zinc-500 dark:text-zinc-400" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.5 3.75V16.25M3.4375 16.25H16.5625C17.08 16.25 17.5 15.83 17.5 15.3125V4.6875C17.5 4.17 17.08 3.75 16.5625 3.75H3.4375C2.92 3.75 2.5 4.17 2.5 4.6875V15.3125C2.5 15.83 2.92 16.25 3.4375 16.25Z" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
        </button>

                    <div popover="manual" class="relative py-2 px-2.5 rounded-md text-xs text-white font-medium bg-zinc-800 dark:bg-zinc-700 dark:border dark:border-white/10 p-0 overflow-visible" data-flux-tooltip-content>
    Toggle sidebar

    </div>
            </ui-tooltip>
</ui-sidebar-toggle>
<?php echo ltrim(ob_get_clean()); ?>
            <?php echo trim(ob_get_clean()); ?>

</div><?php echo ltrim(ob_get_clean()); ?>

            <?php ob_start(); ?><nav class="flex flex-col overflow-visible min-h-auto min-w-0 max-w-full overflow-x-hidden overflow-y-auto px-3 py-4" style="max-height: calc(100dvh - 13rem);" data-flux-sidebar-nav>
    <?php ob_start(); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->hasRole('administrator')): ?>
                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="dashboard"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">DASHBOARD</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'home','href' => route('dashboard') . '#system-overview','current' => request()->routeIs('dashboard'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            System Overview
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'chart-bar','href' => route('dashboard') . '#bst-mif-comparison','current' => false,'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            BST ↔ MIF Comparison
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('system.activity'),'current' => request()->routeIs('system.activity'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Activity Logs
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'chart-bar','href' => route('dashboard') . '#quick-stats','current' => false,'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Quick Stats
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="enrollment"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">ENROLLMENT MONITORING</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('enrollments.index', ['status' => 'submitted']),'current' => request()->routeIs('enrollments.index') && request()->query('status') === 'submitted','wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Submissions
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('enrollments.index', ['status' => 'confirmed']),'current' => request()->routeIs('enrollments.index') && request()->query('status') === 'confirmed','wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Verified Records
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'document-arrow-down','href' => route('system.forwarded-batches'),'current' => request()->routeIs('system.forwarded-batches'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Forwarded Batches
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'chart-bar','href' => route('system.intake-summary'),'current' => request()->routeIs('system.intake-summary'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Intake Summary
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="scheduling"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">SCHEDULING MANAGEMENT</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'calendar-days','href' => route('schedules.index'),'current' => request()->routeIs('schedules.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Create / Edit
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'calendar-days','href' => route('system.calendar'),'current' => request()->routeIs('system.calendar'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Calendar
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'calendar-days','href' => route('system.duration-compliance'),'current' => request()->routeIs('system.duration-compliance'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Duration Compliance
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'calendar-days','href' => route('system.batches'),'current' => request()->routeIs('system.batches'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Batch Management
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'book-open','href' => route('system.courses'),'current' => request()->routeIs('system.courses'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Course Setup
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'building-office-2','href' => route('system.institutions'),'current' => request()->routeIs('system.institutions'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Institution Setup
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('competencies.index'),'current' => request()->routeIs('competencies.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Competency Setup
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('attendance.index'),'current' => request()->routeIs('attendance.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Attendance Management
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="system-monitoring"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">SYSTEM MONITORING</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'users','href' => route('system.accounts'),'current' => request()->routeIs('system.accounts'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Accounts
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'shield-check','href' => route('system.activity'),'current' => request()->routeIs('system.activity'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Audit Logs
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('announcements.index'),'current' => request()->routeIs('announcements.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Announcement Monitor
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'cog','href' => route('system.health'),'current' => request()->routeIs('system.health'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Health
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="reports"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">REPORTS &amp; OVERSIGHT</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'chart-bar','href' => route('progress.competency'),'current' => request()->routeIs('progress.competency'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Progress
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'academic-cap','href' => route('progress.index'),'current' => request()->routeIs('progress.index'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Scholar Monitoring
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'academic-cap','href' => route('certification.index'),'current' => request()->routeIs('certification.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Completion
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'chart-bar','href' => route('reports.index'),'current' => request()->routeIs('reports.index'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Performance
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <div class="tesda-nav-subheading px-3 pt-3 pb-1 text-[10px] font-bold">Export</div>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'document-arrow-down','href' => route('reports.export', ['type' => 'enrollments']),'current' => false]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Enrollment CSV
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'document-arrow-down','href' => route('reports.export', ['type' => 'competency-progress']),'current' => false]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Competency CSV
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'document-arrow-down','href' => route('reports.export', ['type' => 'attendance']),'current' => false]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Attendance CSV
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>
                <?php elseif($user->hasRole('registrar')): ?>
                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="registrar-dashboard"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">DASHBOARD</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'home','href' => route('dashboard'),'current' => request()->routeIs('dashboard'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Dashboard &amp; Recent Submissions
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'users','href' => route('registrar.account-requests'),'current' => request()->routeIs('registrar.account-requests'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Account Requests
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="registrar-enrollment"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">ENROLLMENT MANAGEMENT</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('enrollments.index'),'current' => request()->routeIs('enrollments.index'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Review / Verify / Confirm Enrollments
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'calendar-days','href' => route('registrar.intake'),'current' => request()->routeIs('registrar.intake'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Intake Acceptance &amp; Quotas
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'document-arrow-down','href' => route('registrar.forward-batches'),'current' => request()->routeIs('registrar.forward-batches'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Forward Confirmed Batch to Admin
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="registrar-student-records"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">STUDENT RECORDS</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'users','href' => route('registrar.student-records'),'current' => request()->routeIs('registrar.student-records'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Student Records (Search, Update &amp; Archive)
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="registrar-announcements"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">ANNOUNCEMENTS</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'megaphone','href' => route('announcements.index'),'current' => request()->routeIs('announcements.index'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Manage Announcements
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="registrar-account-management"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">ACCOUNT MANAGEMENT</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'users','href' => route('registrar.accounts'),'current' => request()->routeIs('registrar.accounts'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Staff Accounts (Passwords, Verification &amp; Status)
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="registrar-institutions"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">INSTITUTIONS</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'building-office-2','href' => route('registrar.institutions'),'current' => request()->routeIs('registrar.institutions'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Institution Records &amp; Side-by-Side Summary
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>
                <?php elseif($user->hasRole('focal_person')): ?>
                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="focal-dashboard"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">DASHBOARD</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'home','href' => route('dashboard'),'current' => request()->routeIs('dashboard'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Dashboard &amp; Institution Overview
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="focal-competency"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">COMPETENCY PROGRESS &amp;amp; ACHIEVEMENT</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'chart-bar','href' => route('progress.competency'),'current' => request()->routeIs('progress.competency'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Progress Charts, Update, Review &amp; Submit Summary
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('competencies.index'),'current' => request()->routeIs('competencies.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Competency Units &amp; Tasks Setup
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'chart-bar','href' => route('progress.index'),'current' => request()->routeIs('progress.index'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Scholar Completion Overview
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="focal-courses"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">COURSE MANAGEMENT</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'book-open','href' => route('focal.courses'),'current' => request()->routeIs('focal.courses'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Register, Update &amp; Archive Courses
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="focal-certification"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">CERTIFICATION MANAGEMENT</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'academic-cap','href' => route('certification.index'),'current' => request()->routeIs('certification.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Batch Certification &amp; Issue Certificate
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="focal-documents"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">DOCUMENT &amp;amp; ADMIN TASKS</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('attendance.index'),'current' => request()->routeIs('attendance.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Attendance Management
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'folder-open','href' => route('focal.documents'),'current' => request()->routeIs('focal.documents'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Upload / Download Document Library
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'printer','href' => route('focal.forms'),'current' => request()->routeIs('focal.forms*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Generate Forms &amp; Secretarial Log
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'calendar-days','href' => route('schedules.index'),'current' => request()->routeIs('schedules.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Batch Scheduling
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="focal-reports"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">REPORTS &amp;amp; COMMUNICATION</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'chart-bar','href' => route('reports.index'),'current' => request()->routeIs('reports.index'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Reports &amp; Oversight
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'megaphone','href' => route('announcements.index'),'current' => request()->routeIs('announcements.index'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Announcements
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>
                <?php elseif($user->hasRole('applicant', 'scholar')): ?>
                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="learner-dashboard"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">DASHBOARD</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'home','href' => route('learner.portal'),'current' => request()->routeIs('learner.portal'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Student / Scholar Dashboard
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>

                    <?php ob_start(); ?><ui-disclosure class="group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-tesda-sidebar-group="learner-enrollment"  data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! hidden group-data-open/disclosure-button:block" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
</svg>

                            <svg class="shrink-0 [:where(&amp;)]:size-6 size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg>

                        </div>

                <span class="text-sm font-medium truncate">ENROLLMENT SUBMISSION</span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" >
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'document-text','href' => route('learner.requirements'),'current' => request()->routeIs('learner.requirements'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            View Requirements
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('learner.registration'),'current' => request()->routeIs('learner.registration'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Submit Enrollment / Registration Form
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

                </div>
            </div>
        </ui-disclosure>
    
<?php echo ltrim(ob_get_clean()); ?>
                <?php elseif($user->hasRole('focal_person')): ?>
                    <?php ob_start(); ?><div class="flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden grid text-blue-200" data-flux-sidebar-group>
        <div class="px-3 py-2 text-sm text-zinc-400 font-medium leading-none truncate">MAIN MENU</div>

        <div class="flex flex-col min-w-0">
            <?php ob_start(); ?>
                        <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'home','href' => route('dashboard'),'current' => request()->routeIs('dashboard'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                            Dashboard
                        <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                    <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'book-open','href' => route('user-guide'),'current' => request()->routeIs('user-guide'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                        User Guide
                    <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->hasRole('registrar')): ?>
                            <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('enrollments.index'),'current' => request()->routeIs('enrollments.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                                Enrollment Monitoring
                            <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->hasRole('registrar', 'focal_person')): ?>
                            <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'calendar-days','href' => route('schedules.index'),'current' => request()->routeIs('schedules.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                                Scheduling Management
                            <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->hasRole('focal_person')): ?>
                            <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'academic-cap','href' => route('progress.index'),'current' => request()->routeIs('progress.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                                Progress & Achievement
                            <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>

                            <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('attendance.index'),'current' => request()->routeIs('attendance.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                                Attendance Management
                            <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>

                            <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'chart-bar','href' => route('progress.competency'),'current' => request()->routeIs('progress.competency'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                                Competency Progress
                            <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>

                            <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('competencies.index'),'current' => request()->routeIs('competencies.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                                Competency Setup
                            <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>

                            <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'academic-cap','href' => route('certification.index'),'current' => request()->routeIs('certification.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                                Certification Management
                            <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->hasRole('registrar', 'focal_person')): ?>
                            <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'chart-bar','href' => route('reports.index'),'current' => request()->routeIs('reports.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                                Reports & Oversight
                            <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>

                            <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('announcements.index'),'current' => request()->routeIs('announcements.*'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                                Announcements
                            <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->hasRole('applicant', 'scholar')): ?>
                            <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'clipboard-document-list','href' => route('learner.registration'),'current' => request()->routeIs('learner.registration'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                                Registration Form
                            <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>

                            <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'academic-cap','href' => route('learner.portal'),'current' => request()->routeIs('learner.portal'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                                My Learning Portal
                            <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php echo trim(ob_get_clean()); ?>

        </div>
    </div>
<?php echo ltrim(ob_get_clean()); ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php echo trim(ob_get_clean()); ?>

</nav>
<?php echo ltrim(ob_get_clean()); ?>

            <?php ob_start(); ?><div class="flex-1" data-flux-spacer></div>
<?php echo ltrim(ob_get_clean()); ?>
            <div data-user-guide-sidebar class="px-3 pb-3">
                <?php if (!function_exists('_f324b76fc9fb0cbadba6b2cd8d21a4ba')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php', $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'); require $__blaze->compiledPath.'/f324b76fc9fb0cbadba6b2cd8d21a4ba.php'; } ?>
<?php if (isset($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php if (isset($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba[] = $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba; } ?>
<?php $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = ['icon' => 'book-open','href' => route('user-guide'),'current' => request()->routeIs('user-guide'),'wire:navigate' => true]; ?>
<?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = []; ?>
<?php $__blaze->pushData($__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php ob_start(); ?>
                    User Guide &amp; Role Handbook
                <?php $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba); ?>
<?php _f324b76fc9fb0cbadba6b2cd8d21a4ba($__blaze, $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba, $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba, ['href', 'current', 'wire:navigate'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__slotsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__slotsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php if (! empty($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba)) { $__attrsf324b76fc9fb0cbadba6b2cd8d21a4ba = array_pop($__attrsStackf324b76fc9fb0cbadba6b2cd8d21a4ba); } ?>
<?php $__blaze->popData(); ?>
            </div>


            <div class="border-t border-white/10 p-4">
                <div class="flex items-center gap-3 rounded-xl bg-white/10 p-3">
                    <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::avatar", ['name' => $user->name, 'initials' => $user->initials(), 'class' => 'bg-cyan-400 text-[#102f68]']); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php if (!function_exists('_d53b2086bafbc0f3d0ab68331ed54bcc')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/avatar/index.blade.php', $__blaze->compiledPath.'/d53b2086bafbc0f3d0ab68331ed54bcc.php'); require $__blaze->compiledPath.'/d53b2086bafbc0f3d0ab68331ed54bcc.php'; } ?>
<?php $__blaze->pushData(['name' => $user->name,'initials' => $user->initials(),'class' => 'bg-cyan-400 text-[#102f68]']); ?>
<?php _d53b2086bafbc0f3d0ab68331ed54bcc($__blaze, ['name' => $user->name,'initials' => $user->initials(),'class' => 'bg-cyan-400 text-[#102f68]'], [], ['name', 'initials'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>

                    <div class="min-w-0 flex-1">
                        <p class="tesda-user-name truncate text-sm font-semibold">
                            <?php echo e($user->name); ?>

                        </p>

                        <p class="tesda-user-role truncate text-xs">
                            <?php echo e($user->roleLabel()); ?>

                        </p>
                    </div>
                </div>

                <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-3">
                    <?php echo csrf_field(); ?>

                    <button
                        type="submit"
                        class="tesda-logout flex w-full items-center justify-center gap-2 rounded-lg border border-white/20 px-3 py-2 text-sm font-semibold transition hover:bg-white/10"
                    >
                        <?php ob_start(); ?><svg class="shrink-0 [:where(&amp;)]:size-6 size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9"/>
</svg>

        <?php echo ltrim(ob_get_clean()); ?>
                        Sign out
                    </button>
                </form>
            </div>
        <?php echo trim(ob_get_clean()); ?>

</ui-sidebar>
<?php echo ltrim(ob_get_clean()); ?>

        <?php ob_start(); ?><header class="[grid-area:header] z-10 min-h-14 flex items-center px-6 lg:px-8 border-b border-slate-200 bg-white px-4 shadow-sm lg:px-7" data-flux-header>
            <?php ob_start(); ?>
            <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 w-10 inline-flex -ms-2.5 bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white       shrink-0 lg:hidden" data-flux-button="data-flux-button" x-data="" x-on:click="$dispatch('flux-sidebar-toggle')" aria-label="Toggle sidebar" data-flux-sidebar-toggle="data-flux-sidebar-toggle">
        <svg class="shrink-0 [:where(&amp;)]:size-5" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M2 4.75A.75.75 0 0 1 2.75 4h14.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 4.75ZM2 10a.75.75 0 0 1 .75-.75h14.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 10Zm0 5.25a.75.75 0 0 1 .75-.75h14.5a.75.75 0 0 1 0 1.5H2.75a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd"/>
</svg>
    </button>
<?php echo ltrim(ob_get_clean()); ?>

            <div class="hidden items-center gap-2 text-sm text-slate-500 md:flex">
                <span>TESDAConnect</span>
                <span class="text-slate-300">/</span>
                <span class="font-semibold text-slate-700">
                    <?php echo e($title ?? 'Dashboard'); ?>

                </span>
            </div>

            <?php ob_start(); ?><div class="flex-1" data-flux-spacer></div>
<?php echo ltrim(ob_get_clean()); ?>

            <div class="hidden items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700 sm:flex">
                <span class="size-2 rounded-full bg-emerald-500"></span>
                Online
            </div>

            <a
                href="<?php echo e(route('profile.edit')); ?>"
                class="ml-3 flex items-center gap-2 rounded-xl p-1.5 transition hover:bg-slate-100"
                wire:navigate
            >
                <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::avatar", ['name' => $user->name, 'initials' => $user->initials(), 'class' => 'bg-cyan-500 text-white']); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php if (!function_exists('_d53b2086bafbc0f3d0ab68331ed54bcc')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/avatar/index.blade.php', $__blaze->compiledPath.'/d53b2086bafbc0f3d0ab68331ed54bcc.php'); require $__blaze->compiledPath.'/d53b2086bafbc0f3d0ab68331ed54bcc.php'; } ?>
<?php $__blaze->pushData(['name' => $user->name,'initials' => $user->initials(),'class' => 'bg-cyan-500 text-white']); ?>
<?php _d53b2086bafbc0f3d0ab68331ed54bcc($__blaze, ['name' => $user->name,'initials' => $user->initials(),'class' => 'bg-cyan-500 text-white'], [], ['name', 'initials'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>

                <span class="hidden text-left sm:grid">
                    <span class="text-sm font-semibold leading-tight">
                        <?php echo e($user->name); ?>

                    </span>

                    <span class="text-xs text-slate-500">
                        <?php echo e($user->roleLabel()); ?>

                    </span>
                </span>
            </a>
        <?php echo trim(ob_get_clean()); ?>

    </header>
<?php echo ltrim(ob_get_clean()); ?>

        <?php echo e($slot); ?>


        <?php app("livewire")->forceAssetInjection(); ?><div x-persist="<?php echo e('toast'); ?>">
            <?php ob_start(); ?><ui-toast-group x-data x-on:toast-show.document="$el.showToast($event.detail)" popover="manual" position="bottom end"  wire:ignore>
    <?php ob_start(); ?>
                <?php ob_start(); ?><ui-toast x-data x-on:toast-show.document="! $el.closest('ui-toast-group') && $el.showToast($event.detail)" popover="manual" position="bottom end" wire:ignore>
    <template>
        <div class="group/toast max-w-sm in-[ui-toast-group]:max-w-auto in-[ui-toast-group]:w-xs sm:in-[ui-toast-group]:w-sm" data-variant=""  data-flux-toast-dialog>
            <div class="p-2 flex rounded-xl shadow-lg bg-white border border-zinc-200 border-b-zinc-300/80 dark:bg-zinc-700 dark:border-zinc-600 group-data-invert/toast:bg-zinc-800 group-data-invert/toast:border-zinc-700 dark:group-data-invert/toast:bg-white dark:group-data-invert/toast:border-zinc-200 dark:group-data-invert/toast:border-b-zinc-300/80">
                <div class="flex-1 flex items-start gap-4 has-data-flux-toast-action:gap-2 overflow-hidden">
                    <div class="flex-1 py-1.5 ps-2.5 flex gap-2">
                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=success]_&]:block shrink-0 mt-0.5 size-4 text-lime-600 dark:text-lime-400">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14Zm3.844-8.791a.75.75 0 0 0-1.188-.918l-3.7 4.79-1.649-1.833a.75.75 0 1 0-1.114 1.004l2.25 2.5a.75.75 0 0 0 1.15-.043l4.25-5.5Z" clip-rule="evenodd" />
                        </svg>

                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=warning]_&]:block shrink-0 mt-0.5 size-4 text-amber-500 dark:text-amber-400">
                            <path fill-rule="evenodd" d="M6.701 2.25c.577-1 2.02-1 2.598 0l5.196 9a1.5 1.5 0 0 1-1.299 2.25H2.804a1.5 1.5 0 0 1-1.3-2.25l5.197-9ZM8 4a.75.75 0 0 1 .75.75v3a.75.75 0 1 1-1.5 0v-3A.75.75 0 0 1 8 4Zm0 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z" clip-rule="evenodd" />
                        </svg>

                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=info]_&]:block shrink-0 mt-0.5 size-4 text-cyan-500 dark:text-cyan-400">
                            <path fill-rule="evenodd" d="M15 8A7 7 0 1 1 1 8a7 7 0 0 1 14 0ZM9 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0ZM6.75 8a.75.75 0 0 0 0 1.5h.75v1.75a.75.75 0 0 0 1.5 0v-2.5A.75.75 0 0 0 8.25 8h-1.5Z" clip-rule="evenodd" />
                        </svg>

                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="hidden [[data-flux-toast-dialog][data-variant=danger]_&]:block shrink-0 mt-0.5 size-4 text-rose-500 dark:text-rose-400">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14ZM8 4a.75.75 0 0 1 .75.75v3a.75.75 0 0 1-1.5 0v-3A.75.75 0 0 1 8 4Zm0 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z" clip-rule="evenodd" />
                        </svg>

                        <div>
                            
                            <div class="font-medium text-sm text-zinc-800 dark:text-white group-data-invert/toast:text-white dark:group-data-invert/toast:text-zinc-800 [&:not(:empty)+div]:font-normal [&:not(:empty)+div]:text-zinc-500 [&:not(:empty)+div]:dark:text-zinc-300 group-data-invert/toast:[&:not(:empty)+div]:text-zinc-300 dark:group-data-invert/toast:[&:not(:empty)+div]:text-zinc-500 [&:not(:empty)]:pb-2"><slot name="heading"></slot></div>

                            
                            <div class="font-medium text-sm text-zinc-800 dark:text-white group-data-invert/toast:text-white dark:group-data-invert/toast:text-zinc-800"><slot name="text"></slot></div>

                            
                            <template name="link">
                                <a class="block mt-2 font-medium text-sm text-[var(--color-accent-content)] decoration-[color-mix(in_oklab,var(--color-accent-content),transparent_80%)] underline underline-offset-[6px] hover:decoration-current group-data-invert/toast:text-white group-data-invert/toast:decoration-white/20 dark:group-data-invert/toast:text-zinc-800 dark:group-data-invert/toast:decoration-zinc-800/20"><slot name="text"></slot></a>
                            </template>
                        </div>
                    </div>

                    <div class="flex items-center gap-1">
                        
                        <template name="action">
                            <div class="flex items-center" data-flux-toast-action>
                                <button type="button" data-flux-toast-action-button class="relative inline-flex h-8 items-center justify-center gap-2 whitespace-nowrap rounded-md bg-zinc-800/5 px-3 text-sm font-medium text-zinc-800 hover:bg-zinc-800/10 data-loading:pointer-events-none dark:bg-white/10 dark:text-white dark:hover:bg-white/20 group-data-invert/toast:bg-white/10 group-data-invert/toast:text-white group-data-invert/toast:hover:bg-white/20 dark:group-data-invert/toast:bg-zinc-800/5 dark:group-data-invert/toast:text-zinc-800 dark:group-data-invert/toast:hover:bg-zinc-800/10 [&[data-loading]_[data-flux-toast-action-label]]:opacity-0 [&[data-loading]_[data-flux-loading-indicator]]:opacity-100">
                                    <span class="transition-opacity" data-flux-toast-action-label></span>
                                    <span class="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity" data-flux-loading-indicator>
                                        <svg class="size-4 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true">
                                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 0 1 8-8V0C5.373 0 0 5.373 0 12h4Z"></path>
                                        </svg>
                                    </span>
                                </button>

                                <a data-flux-toast-action-link class="inline-flex h-8 items-center justify-center gap-2 whitespace-nowrap rounded-md bg-zinc-800/5 px-3 text-sm font-medium text-zinc-800 hover:bg-zinc-800/10 dark:bg-white/10 dark:text-white dark:hover:bg-white/20 group-data-invert/toast:bg-white/10 group-data-invert/toast:text-white group-data-invert/toast:hover:bg-white/20 dark:group-data-invert/toast:bg-zinc-800/5 dark:group-data-invert/toast:text-zinc-800 dark:group-data-invert/toast:hover:bg-zinc-800/10">
                                    <span data-flux-toast-action-label></span>
                                </a>
                            </div>
                        </template>

                        
                        <ui-close class="flex items-center">
                            <button type="button" class="inline-flex items-center font-medium justify-center gap-2 truncate disabled:opacity-50 dark:disabled:opacity-75 disabled:cursor-default h-8 text-sm rounded-md w-8 bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-400 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white group-data-invert/toast:hover:bg-white/15 group-data-invert/toast:hover:text-white dark:group-data-invert/toast:hover:bg-zinc-800/5 dark:group-data-invert/toast:hover:text-zinc-800" as="button">
                                <div>
                                    <svg class="[:where(&)]:size-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" data-slot="icon">
                                        <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z"></path>
                                    </svg>
                                </div>
                            </button>
                        </ui-close>
                    </div>
                </div>
            </div>
        </div>
    </template>
</ui-toast>
<?php echo ltrim(ob_get_clean()); ?>
            <?php echo trim(ob_get_clean()); ?>

</ui-toast-group>
<?php echo ltrim(ob_get_clean()); ?>
        </div>


        <script>
            (() => {
                const storageKey = <?php echo \Illuminate\Support\Js::from('tesda-connect-v2:sidebar-groups:' . (string) $user->getAuthIdentifier())->toHtml() ?>;
                const rootSelector = '.tesda-sidebar';
                const globalKey = '__tesdaConnectSidebarGroupPersistenceV2';

                // The layout may be visited again through Livewire wire:navigate.
                // Keep one delegated listener while restoring the saved state on each navigation.
                if (window[globalKey]) {
                    window[globalKey].restore();
                    return;
                }

                let restoring = false;

                const readState = () => {
                    try {
                        const value = JSON.parse(window.localStorage.getItem(storageKey) || '{}');
                        if (!value || typeof value !== 'object') return { openGroup: null };

                        // Backward-compatible migration from the previous { groupId: true/false } format.
                        if (typeof value.openGroup === 'string' || value.openGroup === null) {
                            return { openGroup: value.openGroup || null };
                        }

                        const legacyOpenGroup = Object.keys(value).find((key) => value[key] === true);
                        return { openGroup: legacyOpenGroup || null };
                    } catch (error) {
                        return { openGroup: null };
                    }
                };

                const writeState = (openGroup) => {
                    try {
                        window.localStorage.setItem(storageKey, JSON.stringify({ openGroup: openGroup || null }));
                    } catch (error) {
                        // If storage is disabled, the sidebar still works for the current page.
                    }
                };

                const groups = () => Array.from(document.querySelectorAll(`${rootSelector} [data-tesda-sidebar-group]`));
                const findTrigger = (group) => group.querySelector('button[aria-expanded], [role="button"][aria-expanded]');

                const setExpanded = (group, shouldExpand) => {
                    const trigger = findTrigger(group);
                    if (!trigger) return;

                    const isExpanded = trigger.getAttribute('aria-expanded') === 'true';
                    if (shouldExpand !== isExpanded) {
                        restoring = true;
                        trigger.click();
                        restoring = false;
                    }
                };

                const restore = () => {
                    window.requestAnimationFrame(() => {
                        const state = readState();
                        const availableGroups = groups();
                        const savedOpenGroup = availableGroups.some((group) => group.getAttribute('data-tesda-sidebar-group') === state.openGroup)
                            ? state.openGroup
                            : null;

                        // Accordion behavior: restore exactly one open section; every other section stays closed.
                        availableGroups.forEach((group) => {
                            const id = group.getAttribute('data-tesda-sidebar-group');
                            setExpanded(group, id === savedOpenGroup);
                        });

                        // Normalize older saved state to the exclusive single-open format.
                        if (savedOpenGroup !== state.openGroup) writeState(savedOpenGroup);
                    });
                };

                document.addEventListener('click', (event) => {
                    if (!(event.target instanceof Element)) return;

                    const trigger = event.target.closest(
                        `${rootSelector} [data-tesda-sidebar-group] button[aria-expanded], ` +
                        `${rootSelector} [data-tesda-sidebar-group] [role="button"][aria-expanded]`
                    );

                    if (!trigger || restoring) return;

                    const group = trigger.closest('[data-tesda-sidebar-group]');
                    const id = group?.getAttribute('data-tesda-sidebar-group');
                    if (!id) return;

                    // Wait until Flux toggles the clicked group, then close every other section.
                    window.setTimeout(() => {
                        const isExpanded = trigger.getAttribute('aria-expanded') === 'true';
                        if (isExpanded) {
                            groups().forEach((otherGroup) => {
                                if (otherGroup !== group) setExpanded(otherGroup, false);
                            });
                            writeState(id);
                        } else {
                            writeState(null);
                        }
                    }, 0);
                });

                window[globalKey] = { restore };
                document.addEventListener('livewire:navigated', restore);
                document.addEventListener('DOMContentLoaded', restore, { once: true });
                if (document.readyState !== 'loading') restore();
            })();
        </script>

        <?php echo $__env->make('layouts.app.partials.scroll-controls', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\tesda-connect-v2\resources\views/layouts/app/sidebar.blade.php ENDPATH**/ ?>