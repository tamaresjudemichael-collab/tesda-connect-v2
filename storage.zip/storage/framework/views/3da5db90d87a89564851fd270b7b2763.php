<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::text}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/text.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::link}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/link.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::link}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/link.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php if (isset($component)) { $__componentOriginal08b8a564843783787e0bee3357e24f38 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal08b8a564843783787e0bee3357e24f38 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'f4ac99e09542ff494432bc959d4fee61::auth','data' => ['title' => __('Sign in')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts::auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Sign in'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php ob_start(); ?><?php $__blaze->pushData(['class' => 'login-card border border-white/15 bg-[#102120]/95 p-6 !text-white shadow-2xl shadow-black/30 sm:p-10']); $__env->pushConsumableComponentData(['class' => 'login-card border border-white/15 bg-[#102120]/95 p-6 !text-white shadow-2xl shadow-black/30 sm:p-10']); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 login-card border border-white/15 bg-[#102120]/95 p-6 !text-white shadow-2xl shadow-black/30 sm:p-10" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?>
        <div class="flex items-start justify-between gap-4">
            <div>
                <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-2xl [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2 text-3xl font-black tracking-tight !text-white" data-flux-heading><?php ob_start(); ?>
                    Welcome back <span aria-hidden="true">👋</span>
                <?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>

                <?php ob_start(); ?><p class="[:where(&amp;)]:font-normal [:where(&amp;)]:text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 mt-2 text-base leading-6 !text-white/90" data-flux-text ><?php ob_start(); ?>
                    Sign in to access your TESDA Connect workspace.
                <?php echo trim(ob_get_clean()); ?></p><?php echo ltrim(ob_get_clean()); ?>
            </div>

            <a
                href="<?php echo e(route('home')); ?>"
                class="grid size-10 shrink-0 place-items-center rounded-full bg-white/10 text-xl text-white/80 transition hover:bg-white/20 hover:text-white"
                wire:navigate
                aria-label="Back to home"
            >
                ×
            </a>
        </div>

        <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mt-5 text-center text-sm !text-white','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-5 text-center text-sm !text-white','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>

        <form method="POST" action="<?php echo e(route('login.store')); ?>" class="mt-7 flex flex-col gap-5">
            <?php echo csrf_field(); ?>

                        <?php if (!function_exists('_6a8628270b42f84850a98ca1b053149a')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/input/index.blade.php', $__blaze->compiledPath.'/6a8628270b42f84850a98ca1b053149a.php'); require $__blaze->compiledPath.'/6a8628270b42f84850a98ca1b053149a.php'; } ?>
<?php $__blaze->pushData(['name' => 'email','label' => __('Email address'),'value' => old('email', app()->environment('local') ? 'admin@tesdaconnect.test' : ''),'type' => 'email','required' => true,'autofocus' => true,'autocomplete' => 'email','placeholder' => 'you@example.com','class' => '[--flux-input-background:#ffffff] [--flux-input-border-color:#d1d5db] [--flux-input-color:#111827] [--flux-input-placeholder-color:#6b7280] [&_.\[\:where\(\&\)\]\:text-zinc-800]:!text-white [&_[data-flux-label]]:!text-white [&_label]:!text-white [&_label]:!opacity-100']); ?>
<?php _6a8628270b42f84850a98ca1b053149a($__blaze, ['name' => 'email','label' => __('Email address'),'value' => old('email', app()->environment('local') ? 'admin@tesdaconnect.test' : ''),'type' => 'email','required' => true,'autofocus' => true,'autocomplete' => 'email','placeholder' => 'you@example.com','class' => '[--flux-input-background:#ffffff] [--flux-input-border-color:#d1d5db] [--flux-input-color:#111827] [--flux-input-placeholder-color:#6b7280] [&_.\[\:where\(\&\)\]\:text-zinc-800]:!text-white [&_[data-flux-label]]:!text-white [&_label]:!text-white [&_label]:!opacity-100'], [], ['label', 'value', 'required', 'autofocus'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>

            <div class="relative">
                <?php if (!function_exists('_6a8628270b42f84850a98ca1b053149a')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/input/index.blade.php', $__blaze->compiledPath.'/6a8628270b42f84850a98ca1b053149a.php'); require $__blaze->compiledPath.'/6a8628270b42f84850a98ca1b053149a.php'; } ?>
<?php $__blaze->pushData(['name' => 'password','label' => __('Password'),'type' => 'password','required' => true,'autocomplete' => 'current-password','value' => app()->environment('local') ? 'admin123' : '','placeholder' => __('Enter your password'),'viewable' => true,'class' => '[--flux-input-background:#ffffff] [--flux-input-border-color:#d1d5db] [--flux-input-color:#111827] [--flux-input-placeholder-color:#6b7280] [&_.\[\:where\(\&\)\]\:text-zinc-800]:!text-white [&_[data-flux-label]]:!text-white [&_label]:!text-white [&_label]:!opacity-100']); ?>
<?php _6a8628270b42f84850a98ca1b053149a($__blaze, ['name' => 'password','label' => __('Password'),'type' => 'password','required' => true,'autocomplete' => 'current-password','value' => app()->environment('local') ? 'admin123' : '','placeholder' => __('Enter your password'),'viewable' => true,'class' => '[--flux-input-background:#ffffff] [--flux-input-border-color:#d1d5db] [--flux-input-color:#111827] [--flux-input-placeholder-color:#6b7280] [&_.\[\:where\(\&\)\]\:text-zinc-800]:!text-white [&_[data-flux-label]]:!text-white [&_label]:!text-white [&_label]:!opacity-100'], [], ['label', 'required', 'value', 'placeholder', 'viewable'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('password.request')): ?>
                    <?php ob_start(); ?><a class="inline font-medium underline-offset-[6px] hover:decoration-current underline [[data-color]&gt;&amp;]:text-inherit [[data-color]&gt;&amp;]:decoration-current/20 dark:[[data-color]&gt;&amp;]:decoration-current/50 [[data-color]&gt;&amp;]:hover:decoration-current text-[var(--color-accent-content)] decoration-[color-mix(in_oklab,var(--color-accent-content),transparent_80%)] mt-2 inline-block text-sm font-semibold !text-teal-300 hover:!text-teal-200" <?php if (($__blazeAttr = route('password.request')) !== false && !is_null($__blazeAttr)): ?>href="<?php echo e($__blazeAttr === true ? 'href' : $__blazeAttr); ?>"<?php endif; unset($__blazeAttr); ?> wire:navigate="" data-flux-link ><?php ob_start(); ?>
                        Forgot your password?
                    <?php echo trim(ob_get_clean()); ?></a><?php echo ltrim(ob_get_clean()); ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div class="rounded-lg border border-white/15 bg-white/5 px-3 py-3">
                <?php if (!function_exists('_5c903424813db3116709b5cb37177091')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/checkbox/index.blade.php', $__blaze->compiledPath.'/5c903424813db3116709b5cb37177091.php'); require $__blaze->compiledPath.'/5c903424813db3116709b5cb37177091.php'; } ?>
<?php $__blaze->pushData(['name' => 'remember','label' => __('Remember me on this device'),'checked' => old('remember'),'class' => '[--flux-checkbox-label-color:#ffffff] [&_.\[\:where\(\&\)\]\:text-zinc-800]:!text-white [&_[data-flux-label]]:!text-white [&_label]:!text-white [&_label]:!opacity-100']); ?>
<?php _5c903424813db3116709b5cb37177091($__blaze, ['name' => 'remember','label' => __('Remember me on this device'),'checked' => old('remember'),'class' => '[--flux-checkbox-label-color:#ffffff] [&_.\[\:where\(\&\)\]\:text-zinc-800]:!text-white [&_[data-flux-label]]:!text-white [&_label]:!text-white [&_label]:!opacity-100'], [], ['label', 'checked'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            </div>

            <?php ob_start(); ?><button type="submit" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-4 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[1px]! [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)] *:transition-opacity [&amp;[disabled]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[disabled]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[disabled]]:pointer-events-none   mt-2 w-full py-3 text-base font-bold" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target" data-test="login-button">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
        
                    
            
            <span><?php ob_start(); ?>
                Sign in →
            <?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
        </form>
        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('register')): ?>
            <p class="mt-5 text-center text-sm !text-white/80">
                Don't have an account?
                <?php ob_start(); ?><a class="inline font-medium underline-offset-[6px] hover:decoration-current underline [[data-color]&gt;&amp;]:text-inherit [[data-color]&gt;&amp;]:decoration-current/20 dark:[[data-color]&gt;&amp;]:decoration-current/50 [[data-color]&gt;&amp;]:hover:decoration-current text-[var(--color-accent-content)] decoration-[color-mix(in_oklab,var(--color-accent-content),transparent_80%)] font-bold !text-teal-300 hover:!text-teal-200" <?php if (($__blazeAttr = route('register')) !== false && !is_null($__blazeAttr)): ?>href="<?php echo e($__blazeAttr === true ? 'href' : $__blazeAttr); ?>"<?php endif; unset($__blazeAttr); ?> wire:navigate="" data-flux-link ><?php ob_start(); ?>
                    Register here
                <?php echo trim(ob_get_clean()); ?></a><?php echo ltrim(ob_get_clean()); ?>
            </p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <p class="mt-7 text-center text-xs leading-5 !text-white/80">
            Your approved role and institution access are applied automatically after sign-in.
        </p>

        <div class="mt-6 border-t border-white/15 pt-6">
            <p class="mb-4 text-center text-xs font-semibold uppercase tracking-wider !text-white/60">
                Or sign in another way
            </p>

            <?php if (isset($component)) { $__componentOriginal360dec750a5c22110ff2b6afe54f0581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal360dec750a5c22110ff2b6afe54f0581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.passkey-verify','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('passkey-verify'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal360dec750a5c22110ff2b6afe54f0581)): ?>
<?php $attributes = $__attributesOriginal360dec750a5c22110ff2b6afe54f0581; ?>
<?php unset($__attributesOriginal360dec750a5c22110ff2b6afe54f0581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal360dec750a5c22110ff2b6afe54f0581)): ?>
<?php $component = $__componentOriginal360dec750a5c22110ff2b6afe54f0581; ?>
<?php unset($__componentOriginal360dec750a5c22110ff2b6afe54f0581); ?>
<?php endif; ?>
        </div>
    <?php echo trim(ob_get_clean()); ?>

</div>
<?php $__blaze->popData(); $__env->popConsumableComponentData(); ?><?php echo ltrim(ob_get_clean()); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal08b8a564843783787e0bee3357e24f38)): ?>
<?php $attributes = $__attributesOriginal08b8a564843783787e0bee3357e24f38; ?>
<?php unset($__attributesOriginal08b8a564843783787e0bee3357e24f38); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08b8a564843783787e0bee3357e24f38)): ?>
<?php $component = $__componentOriginal08b8a564843783787e0bee3357e24f38; ?>
<?php unset($__componentOriginal08b8a564843783787e0bee3357e24f38); ?>
<?php endif; ?>

<style>
    .login-card [data-flux-label],
.login-card [data-flux-label] *,
.login-card label,
.login-card label span {
    color: #ffffff !important;
    opacity: 1 !important;
}

.login-card input[data-flux-control],
.login-card textarea[data-flux-control],
.login-card select[data-flux-control] {
    color: #111827 !important;
    background-color: #ffffff !important;
}

.login-card input[data-flux-control]::placeholder,
.login-card textarea[data-flux-control]::placeholder {
    color: #6b7280 !important;
    opacity: 1 !important;
}

.login-card [data-flux-checkbox] {
    color: #ffffff !important;
}

.login-card [data-flux-checkbox] label,
.login-card [data-flux-checkbox] label span {
    color: #ffffff !important;
}
</style><?php /**PATH C:\xampp\htdocs\tesda-connect-v2\resources\views/pages/auth/login.blade.php ENDPATH**/ ?>