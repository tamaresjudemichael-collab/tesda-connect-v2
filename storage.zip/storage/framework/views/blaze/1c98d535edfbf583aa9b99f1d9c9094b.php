<?php
if (!function_exists('__1c98d535edfbf583aa9b99f1d9c9094b')):
function __1c98d535edfbf583aa9b99f1d9c9094b($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'interactive' => null,
    'position' => 'top',
    'align' => 'center',
    'content' => null,
    'kbd' => null,
    'toggleable' => null,
];
$interactive ??= $attributes['interactive'] ?? $__defaults['interactive']; unset($attributes['interactive']);
$position ??= $attributes['position'] ?? $__defaults['position']; unset($attributes['position']);
$align ??= $attributes['align'] ?? $__defaults['align']; unset($attributes['align']);
$content ??= $attributes['content'] ?? $__defaults['content']; unset($attributes['content']);
$kbd ??= $attributes['kbd'] ?? $__defaults['kbd']; unset($attributes['kbd']);
$toggleable ??= $attributes['toggleable'] ?? $__defaults['toggleable']; unset($attributes['toggleable']);
unset($__defaults);
?>

<?php
// Support adding the .self modifier to the wire:model directive...
if (($wireModel = $attributes->wire('model')) && $wireModel->directive && ! $wireModel->hasModifier('self')) {
    unset($attributes[$wireModel->directive]);

    $wireModel->directive .= '.self';

    $attributes = $attributes->merge([$wireModel->directive => $wireModel->value]);
}
?>

<?php if ($toggleable): ?>
    <ui-dropdown position="<?php echo e($position); ?> <?php echo e($align); ?>" <?php echo e($attributes); ?> data-flux-tooltip>
        <?php echo e($slot); ?>


        <?php if ($content !== null): ?>
            <?php if (!function_exists('__e650f68954b5c812fd41d8b1b3ab1bbe')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/content.blade.php', $__blaze->compiledPath.'/e650f68954b5c812fd41d8b1b3ab1bbe.php'); require $__blaze->compiledPath.'/e650f68954b5c812fd41d8b1b3ab1bbe.php'; } ?>
<?php if (isset($__slotse650f68954b5c812fd41d8b1b3ab1bbe)) { $__slotsStacke650f68954b5c812fd41d8b1b3ab1bbe[] = $__slotse650f68954b5c812fd41d8b1b3ab1bbe; } ?>
<?php if (isset($__attrse650f68954b5c812fd41d8b1b3ab1bbe)) { $__attrsStacke650f68954b5c812fd41d8b1b3ab1bbe[] = $__attrse650f68954b5c812fd41d8b1b3ab1bbe; } ?>
<?php $__attrse650f68954b5c812fd41d8b1b3ab1bbe = ['kbd' => $kbd]; ?>
<?php $__slotse650f68954b5c812fd41d8b1b3ab1bbe = []; ?>
<?php $__blaze->pushData($__attrse650f68954b5c812fd41d8b1b3ab1bbe); ?>
<?php ob_start(); ?><?php echo e($content); ?><?php $__slotse650f68954b5c812fd41d8b1b3ab1bbe['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotse650f68954b5c812fd41d8b1b3ab1bbe); ?>
<?php __e650f68954b5c812fd41d8b1b3ab1bbe($__blaze, $__attrse650f68954b5c812fd41d8b1b3ab1bbe, $__slotse650f68954b5c812fd41d8b1b3ab1bbe, ['kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke650f68954b5c812fd41d8b1b3ab1bbe)) { $__slotse650f68954b5c812fd41d8b1b3ab1bbe = array_pop($__slotsStacke650f68954b5c812fd41d8b1b3ab1bbe); } ?>
<?php if (! empty($__attrsStacke650f68954b5c812fd41d8b1b3ab1bbe)) { $__attrse650f68954b5c812fd41d8b1b3ab1bbe = array_pop($__attrsStacke650f68954b5c812fd41d8b1b3ab1bbe); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    </ui-dropdown>
<?php else: ?>
    <ui-tooltip position="<?php echo e($position); ?> <?php echo e($align); ?>" <?php echo e($attributes); ?> data-flux-tooltip <?php if($interactive): ?> interactive <?php endif; ?>>
        <?php echo e($slot); ?>


        <?php if ($content !== null): ?>
            <?php if (!function_exists('__e650f68954b5c812fd41d8b1b3ab1bbe')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/content.blade.php', $__blaze->compiledPath.'/e650f68954b5c812fd41d8b1b3ab1bbe.php'); require $__blaze->compiledPath.'/e650f68954b5c812fd41d8b1b3ab1bbe.php'; } ?>
<?php if (isset($__slotse650f68954b5c812fd41d8b1b3ab1bbe)) { $__slotsStacke650f68954b5c812fd41d8b1b3ab1bbe[] = $__slotse650f68954b5c812fd41d8b1b3ab1bbe; } ?>
<?php if (isset($__attrse650f68954b5c812fd41d8b1b3ab1bbe)) { $__attrsStacke650f68954b5c812fd41d8b1b3ab1bbe[] = $__attrse650f68954b5c812fd41d8b1b3ab1bbe; } ?>
<?php $__attrse650f68954b5c812fd41d8b1b3ab1bbe = ['kbd' => $kbd]; ?>
<?php $__slotse650f68954b5c812fd41d8b1b3ab1bbe = []; ?>
<?php $__blaze->pushData($__attrse650f68954b5c812fd41d8b1b3ab1bbe); ?>
<?php ob_start(); ?><?php echo e($content); ?><?php $__slotse650f68954b5c812fd41d8b1b3ab1bbe['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotse650f68954b5c812fd41d8b1b3ab1bbe); ?>
<?php __e650f68954b5c812fd41d8b1b3ab1bbe($__blaze, $__attrse650f68954b5c812fd41d8b1b3ab1bbe, $__slotse650f68954b5c812fd41d8b1b3ab1bbe, ['kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke650f68954b5c812fd41d8b1b3ab1bbe)) { $__slotse650f68954b5c812fd41d8b1b3ab1bbe = array_pop($__slotsStacke650f68954b5c812fd41d8b1b3ab1bbe); } ?>
<?php if (! empty($__attrsStacke650f68954b5c812fd41d8b1b3ab1bbe)) { $__attrse650f68954b5c812fd41d8b1b3ab1bbe = array_pop($__attrsStacke650f68954b5c812fd41d8b1b3ab1bbe); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    </ui-tooltip>
<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php ENDPATH**/ ?>