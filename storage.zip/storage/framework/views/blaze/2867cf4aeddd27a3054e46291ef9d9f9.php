<?php
if (!function_exists('__2867cf4aeddd27a3054e46291ef9d9f9')):
function __2867cf4aeddd27a3054e46291ef9d9f9($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php $iconTrailing ??= $attributes->pluck('icon:trailing'); ?>
<?php $iconVariant ??= $attributes->pluck('icon:variant'); ?>

<?php
$__defaults = [
    'iconVariant' => 'outline',
    'iconTrailing' => null,
    'expandable' => false,
    'expanded' => true,
    'heading' => null,
    'icon' => null,
];
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$iconTrailing ??= $attributes['icon-trailing'] ?? $attributes['iconTrailing'] ?? $__defaults['iconTrailing']; unset($attributes['iconTrailing'], $attributes['icon-trailing']);
$expandable ??= $attributes['expandable'] ?? $__defaults['expandable']; unset($attributes['expandable']);
$expanded ??= $attributes['expanded'] ?? $__defaults['expanded']; unset($attributes['expanded']);
$heading ??= $attributes['heading'] ?? $__defaults['heading']; unset($attributes['heading']);
$icon ??= $attributes['icon'] ?? $__defaults['icon']; unset($attributes['icon']);
unset($__defaults);
?>

<?php if ($expandable && $heading): ?>
    <?php if ($icon): ?>
        <ui-disclosure <?php echo e($attributes->class('group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden')); ?> <?php if($expanded === true): ?> open <?php endif; ?> data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="px-3">
                    <?php if (is_string($icon) && $icon !== ''): ?>
                        <?php if (!function_exists('__4741af7889f49e43c795af3e6b6ec35c')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/4741af7889f49e43c795af3e6b6ec35c.php'); require $__blaze->compiledPath.'/4741af7889f49e43c795af3e6b6ec35c.php'; } ?>
<?php $__blaze->pushData(['icon' => $icon,'variant' => $iconVariant,'class' => 'size-4']); ?>
<?php __4741af7889f49e43c795af3e6b6ec35c($__blaze, ['icon' => $icon,'variant' => $iconVariant,'class' => 'size-4'], [], ['icon', 'variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    <?php else: ?>
                        <?php echo e($icon); ?>

                    <?php endif; ?>
                </div>

                <span class="flex-1 text-left rtl:text-right text-sm font-medium truncate"><?php echo e($heading); ?></span>

                <div class="ps-3 pe-2.5">
                    <?php if (!function_exists('__72dffafd4f7f1a701bb1dba7885f881c')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-down.blade.php', $__blaze->compiledPath.'/72dffafd4f7f1a701bb1dba7885f881c.php'); require $__blaze->compiledPath.'/72dffafd4f7f1a701bb1dba7885f881c.php'; } ?>
<?php $__blaze->pushData(['class' => 'size-3! hidden group-data-open/disclosure-button:block']); ?>
<?php __72dffafd4f7f1a701bb1dba7885f881c($__blaze, ['class' => 'size-3! hidden group-data-open/disclosure-button:block'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    <?php if (!function_exists('__c28876059df40df9ce1910878324584a')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-right.blade.php', $__blaze->compiledPath.'/c28876059df40df9ce1910878324584a.php'); require $__blaze->compiledPath.'/c28876059df40df9ce1910878324584a.php'; } ?>
<?php $__blaze->pushData(['class' => 'size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180']); ?>
<?php __c28876059df40df9ce1910878324584a($__blaze, ['class' => 'size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                </div>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" <?php if($expanded === true): ?> data-open <?php endif; ?>>
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php echo e($slot); ?>

                </div>
            </div>
        </ui-disclosure>

        <?php if (!function_exists('__ce0ed3226a6889cd978cb5aefcde41cd')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/dropdown.blade.php', $__blaze->compiledPath.'/ce0ed3226a6889cd978cb5aefcde41cd.php'); require $__blaze->compiledPath.'/ce0ed3226a6889cd978cb5aefcde41cd.php'; } ?>
<?php if (isset($__slotsce0ed3226a6889cd978cb5aefcde41cd)) { $__slotsStackce0ed3226a6889cd978cb5aefcde41cd[] = $__slotsce0ed3226a6889cd978cb5aefcde41cd; } ?>
<?php if (isset($__attrsce0ed3226a6889cd978cb5aefcde41cd)) { $__attrsStackce0ed3226a6889cd978cb5aefcde41cd[] = $__attrsce0ed3226a6889cd978cb5aefcde41cd; } ?>
<?php $__attrsce0ed3226a6889cd978cb5aefcde41cd = ['hover' => true,'class' => 'in-data-flux-sidebar-on-mobile:hidden not-in-data-flux-sidebar-collapsed-desktop:hidden','position' => 'right','align' => 'start','dataFluxSidebarGroupDropdown' => true]; ?>
<?php $__slotsce0ed3226a6889cd978cb5aefcde41cd = []; ?>
<?php $__blaze->pushData($__attrsce0ed3226a6889cd978cb5aefcde41cd); ?>
<?php ob_start(); ?>
            <button type="button" class="border-1 border-transparent w-full px-3 in-data-flux-menu:px-2 h-8 flex gap-3 items-center group/disclosure-button my-px rounded-lg in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-menu:w-10 in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-menu:justify-center hover:bg-zinc-800/5 dark:hover:bg-white/[7%] in-data-flux-menu:hover:bg-zinc-50 dark:in-data-flux-menu:hover:bg-zinc-600 text-zinc-500 in-data-flux-menu:text-zinc-800 hover:text-zinc-800 dark:text-white/80 in-data-flux-menu:dark:text-white dark:hover:text-white">
                <?php if ($icon): ?>
                    <div class="relative">
                        <?php if (is_string($icon) && $icon !== ''): ?>
                            <?php if (!function_exists('__4741af7889f49e43c795af3e6b6ec35c')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/4741af7889f49e43c795af3e6b6ec35c.php'); require $__blaze->compiledPath.'/4741af7889f49e43c795af3e6b6ec35c.php'; } ?>
<?php $__blaze->pushData(['icon' => $icon,'variant' => $iconVariant,'class' => 'in-data-flux-menu:text-zinc-400 in-data-flux-menu:dark:text-white/80 in-data-flux-menu:[[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current size-4']); ?>
<?php __4741af7889f49e43c795af3e6b6ec35c($__blaze, ['icon' => $icon,'variant' => $iconVariant,'class' => 'in-data-flux-menu:text-zinc-400 in-data-flux-menu:dark:text-white/80 in-data-flux-menu:[[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current size-4'], [], ['icon', 'variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                        <?php else: ?>
                            <?php echo e($icon); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <span class="hidden in-data-flux-menu:block flex-1 text-start text-sm font-medium leading-none text-zinc-800 dark:text-white"><?php echo e($heading); ?></span>

                <div class="hidden in-data-flux-menu:block">
                    <?php if (!function_exists('__c28876059df40df9ce1910878324584a')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-right.blade.php', $__blaze->compiledPath.'/c28876059df40df9ce1910878324584a.php'); require $__blaze->compiledPath.'/c28876059df40df9ce1910878324584a.php'; } ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'ms-auto size-4 text-zinc-400 [[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current rtl:hidden']); ?>
<?php __c28876059df40df9ce1910878324584a($__blaze, ['variant' => $iconVariant,'class' => 'ms-auto size-4 text-zinc-400 [[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current rtl:hidden'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    <?php if (!function_exists('__26b8136acf32f63526d8a0e13ce062ec')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-left.blade.php', $__blaze->compiledPath.'/26b8136acf32f63526d8a0e13ce062ec.php'); require $__blaze->compiledPath.'/26b8136acf32f63526d8a0e13ce062ec.php'; } ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'ms-auto size-4 text-zinc-400 [[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current hidden rtl:inline']); ?>
<?php __26b8136acf32f63526d8a0e13ce062ec($__blaze, ['variant' => $iconVariant,'class' => 'ms-auto size-4 text-zinc-400 [[data-flux-sidebar-group-dropdown]>button:hover_&]:text-current hidden rtl:inline'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                </div>
            </button>

            <?php if (!function_exists('__a16a472ff6a9c449642894acb4562c8a')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/index.blade.php', $__blaze->compiledPath.'/a16a472ff6a9c449642894acb4562c8a.php'); require $__blaze->compiledPath.'/a16a472ff6a9c449642894acb4562c8a.php'; } ?>
<?php if (isset($__slotsa16a472ff6a9c449642894acb4562c8a)) { $__slotsStacka16a472ff6a9c449642894acb4562c8a[] = $__slotsa16a472ff6a9c449642894acb4562c8a; } ?>
<?php if (isset($__attrsa16a472ff6a9c449642894acb4562c8a)) { $__attrsStacka16a472ff6a9c449642894acb4562c8a[] = $__attrsa16a472ff6a9c449642894acb4562c8a; } ?>
<?php $__attrsa16a472ff6a9c449642894acb4562c8a = []; ?>
<?php $__slotsa16a472ff6a9c449642894acb4562c8a = []; ?>
<?php $__blaze->pushData($__attrsa16a472ff6a9c449642894acb4562c8a); ?>
<?php ob_start(); ?>
                <?php if (!function_exists('__909ddea82df9dd66b0ef367554402e44')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/group.blade.php', $__blaze->compiledPath.'/909ddea82df9dd66b0ef367554402e44.php'); require $__blaze->compiledPath.'/909ddea82df9dd66b0ef367554402e44.php'; } ?>
<?php if (isset($__slots909ddea82df9dd66b0ef367554402e44)) { $__slotsStack909ddea82df9dd66b0ef367554402e44[] = $__slots909ddea82df9dd66b0ef367554402e44; } ?>
<?php if (isset($__attrs909ddea82df9dd66b0ef367554402e44)) { $__attrsStack909ddea82df9dd66b0ef367554402e44[] = $__attrs909ddea82df9dd66b0ef367554402e44; } ?>
<?php $__attrs909ddea82df9dd66b0ef367554402e44 = ['heading' => $heading]; ?>
<?php $__slots909ddea82df9dd66b0ef367554402e44 = []; ?>
<?php $__blaze->pushData($__attrs909ddea82df9dd66b0ef367554402e44); ?>
<?php ob_start(); ?>
                    <?php echo e($slot); ?>

                <?php $__slots909ddea82df9dd66b0ef367554402e44['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots909ddea82df9dd66b0ef367554402e44); ?>
<?php __909ddea82df9dd66b0ef367554402e44($__blaze, $__attrs909ddea82df9dd66b0ef367554402e44, $__slots909ddea82df9dd66b0ef367554402e44, ['heading'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack909ddea82df9dd66b0ef367554402e44)) { $__slots909ddea82df9dd66b0ef367554402e44 = array_pop($__slotsStack909ddea82df9dd66b0ef367554402e44); } ?>
<?php if (! empty($__attrsStack909ddea82df9dd66b0ef367554402e44)) { $__attrs909ddea82df9dd66b0ef367554402e44 = array_pop($__attrsStack909ddea82df9dd66b0ef367554402e44); } ?>
<?php $__blaze->popData(); ?>
            <?php $__slotsa16a472ff6a9c449642894acb4562c8a['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsa16a472ff6a9c449642894acb4562c8a); ?>
<?php __a16a472ff6a9c449642894acb4562c8a($__blaze, $__attrsa16a472ff6a9c449642894acb4562c8a, $__slotsa16a472ff6a9c449642894acb4562c8a, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacka16a472ff6a9c449642894acb4562c8a)) { $__slotsa16a472ff6a9c449642894acb4562c8a = array_pop($__slotsStacka16a472ff6a9c449642894acb4562c8a); } ?>
<?php if (! empty($__attrsStacka16a472ff6a9c449642894acb4562c8a)) { $__attrsa16a472ff6a9c449642894acb4562c8a = array_pop($__attrsStacka16a472ff6a9c449642894acb4562c8a); } ?>
<?php $__blaze->popData(); ?>
        <?php $__slotsce0ed3226a6889cd978cb5aefcde41cd['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsce0ed3226a6889cd978cb5aefcde41cd); ?>
<?php __ce0ed3226a6889cd978cb5aefcde41cd($__blaze, $__attrsce0ed3226a6889cd978cb5aefcde41cd, $__slotsce0ed3226a6889cd978cb5aefcde41cd, ['hover', 'dataFluxSidebarGroupDropdown'], ['dataFluxSidebarGroupDropdown' => 'data-flux-sidebar-group-dropdown'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackce0ed3226a6889cd978cb5aefcde41cd)) { $__slotsce0ed3226a6889cd978cb5aefcde41cd = array_pop($__slotsStackce0ed3226a6889cd978cb5aefcde41cd); } ?>
<?php if (! empty($__attrsStackce0ed3226a6889cd978cb5aefcde41cd)) { $__attrsce0ed3226a6889cd978cb5aefcde41cd = array_pop($__attrsStackce0ed3226a6889cd978cb5aefcde41cd); } ?>
<?php $__blaze->popData(); ?>
    <?php else: ?>
        <ui-disclosure <?php echo e($attributes->class('group/disclosure in-data-flux-sidebar-collapsed-desktop:hidden')); ?> <?php if($expanded === true): ?> open <?php endif; ?> data-flux-sidebar-group>
            <button type="button" class="border-1 border-transparent w-full min-w-0 h-8 in-data-flux-sidebar-on-mobile:h-10 flex items-center group/disclosure-button my-px rounded-lg hover:bg-zinc-800/5 dark:hover:bg-white/[7%] text-zinc-500 hover:text-zinc-800 dark:text-white/80 dark:hover:text-white">
                <div class="ps-3.5 pe-3.5">
                    <?php if (!function_exists('__72dffafd4f7f1a701bb1dba7885f881c')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-down.blade.php', $__blaze->compiledPath.'/72dffafd4f7f1a701bb1dba7885f881c.php'); require $__blaze->compiledPath.'/72dffafd4f7f1a701bb1dba7885f881c.php'; } ?>
<?php $__blaze->pushData(['class' => 'size-3! hidden group-data-open/disclosure-button:block']); ?>
<?php __72dffafd4f7f1a701bb1dba7885f881c($__blaze, ['class' => 'size-3! hidden group-data-open/disclosure-button:block'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    <?php if (!function_exists('__c28876059df40df9ce1910878324584a')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-right.blade.php', $__blaze->compiledPath.'/c28876059df40df9ce1910878324584a.php'); require $__blaze->compiledPath.'/c28876059df40df9ce1910878324584a.php'; } ?>
<?php $__blaze->pushData(['class' => 'size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180']); ?>
<?php __c28876059df40df9ce1910878324584a($__blaze, ['class' => 'size-3! block group-data-open/disclosure-button:hidden rtl:rotate-180'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                </div>

                <span class="text-sm font-medium truncate"><?php echo e($heading); ?></span>
            </button>

            <div class="relative min-w-0 hidden data-open:block ps-7" <?php if($expanded === true): ?> data-open <?php endif; ?>>
                <div class="absolute inset-y-[3px] w-px bg-zinc-200 dark:bg-white/30 start-0 ms-5"></div>

                <div class="flex flex-col">
                    <?php echo e($slot); ?>

                </div>
            </div>
        </ui-disclosure>
    <?php endif; ?>

<?php elseif ($heading): ?>
    <div <?php echo e($attributes->class('flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden')); ?> data-flux-sidebar-group>
        <div class="px-3 py-2 text-sm text-zinc-400 font-medium leading-none truncate"><?php echo e($heading); ?></div>

        <div class="flex flex-col min-w-0">
            <?php echo e($slot); ?>

        </div>
    </div>
<?php else: ?>
    <div <?php echo e($attributes->class('flex flex-col in-data-flux-sidebar-collapsed-desktop:hidden')); ?> data-flux-sidebar-group>
        <?php echo e($slot); ?>

    </div>
<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/group.blade.php ENDPATH**/ ?>