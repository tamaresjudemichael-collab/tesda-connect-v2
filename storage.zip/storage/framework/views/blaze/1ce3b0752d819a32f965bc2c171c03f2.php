<?php
if (!function_exists('__1ce3b0752d819a32f965bc2c171c03f2')):
function __1ce3b0752d819a32f965bc2c171c03f2($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'name',
    'descriptionTrailing',
    'description',
    'label',
    'badge',
]));
?>

<?php $descriptionTrailing = $descriptionTrailing ??= $attributes->pluck('description:trailing'); ?>

<?php
$__defaults = [
    'name' => $attributes->whereStartsWith('wire:model')->first(),
    'descriptionTrailing' => null,
    'description' => null,
    'label' => null,
    'badge' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
$descriptionTrailing ??= $attributes['description-trailing'] ?? $attributes['descriptionTrailing'] ?? $__defaults['descriptionTrailing']; unset($attributes['descriptionTrailing'], $attributes['description-trailing']);
$description ??= $attributes['description'] ?? $__defaults['description']; unset($attributes['description']);
$label ??= $attributes['label'] ?? $__defaults['label']; unset($attributes['label']);
$badge ??= $attributes['badge'] ?? $__defaults['badge']; unset($attributes['badge']);
unset($__defaults);
?>

<?php if (isset($label) || isset($description) || isset($descriptionTrailing)): ?>
    <?php

        $fieldAttributes = Flux::attributesAfter('field:', $attributes, []);
        $labelAttributes = Flux::attributesAfter('label:', $attributes, ['badge' => $badge]);
        $descriptionAttributes = Flux::attributesAfter('description:', $attributes, []);
        $errorAttributes = Flux::attributesAfter('error:', $attributes, ['name' => $name]);
    ?>
    <?php if (!function_exists('__61bc920947117f631858e73d93440bff')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php', $__blaze->compiledPath.'/61bc920947117f631858e73d93440bff.php'); require $__blaze->compiledPath.'/61bc920947117f631858e73d93440bff.php'; } ?>
<?php if (isset($__slots61bc920947117f631858e73d93440bff)) { $__slotsStack61bc920947117f631858e73d93440bff[] = $__slots61bc920947117f631858e73d93440bff; } ?>
<?php if (isset($__attrs61bc920947117f631858e73d93440bff)) { $__attrsStack61bc920947117f631858e73d93440bff[] = $__attrs61bc920947117f631858e73d93440bff; } ?>
<?php $__attrs61bc920947117f631858e73d93440bff = ['attributes' => $fieldAttributes]; ?>
<?php $__slots61bc920947117f631858e73d93440bff = []; ?>
<?php $__blaze->pushData($__attrs61bc920947117f631858e73d93440bff); ?>
<?php ob_start(); ?>
        <?php if (isset($label)): ?>
            <?php if (!function_exists('__c5177c0b431f68fd7b08ecbb2142818f')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php', $__blaze->compiledPath.'/c5177c0b431f68fd7b08ecbb2142818f.php'); require $__blaze->compiledPath.'/c5177c0b431f68fd7b08ecbb2142818f.php'; } ?>
<?php if (isset($__slotsc5177c0b431f68fd7b08ecbb2142818f)) { $__slotsStackc5177c0b431f68fd7b08ecbb2142818f[] = $__slotsc5177c0b431f68fd7b08ecbb2142818f; } ?>
<?php if (isset($__attrsc5177c0b431f68fd7b08ecbb2142818f)) { $__attrsStackc5177c0b431f68fd7b08ecbb2142818f[] = $__attrsc5177c0b431f68fd7b08ecbb2142818f; } ?>
<?php $__attrsc5177c0b431f68fd7b08ecbb2142818f = ['attributes' => $labelAttributes]; ?>
<?php $__slotsc5177c0b431f68fd7b08ecbb2142818f = []; ?>
<?php $__blaze->pushData($__attrsc5177c0b431f68fd7b08ecbb2142818f); ?>
<?php ob_start(); ?><?php echo e($label); ?><?php $__slotsc5177c0b431f68fd7b08ecbb2142818f['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsc5177c0b431f68fd7b08ecbb2142818f); ?>
<?php __c5177c0b431f68fd7b08ecbb2142818f($__blaze, $__attrsc5177c0b431f68fd7b08ecbb2142818f, $__slotsc5177c0b431f68fd7b08ecbb2142818f, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackc5177c0b431f68fd7b08ecbb2142818f)) { $__slotsc5177c0b431f68fd7b08ecbb2142818f = array_pop($__slotsStackc5177c0b431f68fd7b08ecbb2142818f); } ?>
<?php if (! empty($__attrsStackc5177c0b431f68fd7b08ecbb2142818f)) { $__attrsc5177c0b431f68fd7b08ecbb2142818f = array_pop($__attrsStackc5177c0b431f68fd7b08ecbb2142818f); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php if (isset($description)): ?>
            <?php if (!function_exists('__330cf3602d1fc81eef54544db2d798ea')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/330cf3602d1fc81eef54544db2d798ea.php'); require $__blaze->compiledPath.'/330cf3602d1fc81eef54544db2d798ea.php'; } ?>
<?php if (isset($__slots330cf3602d1fc81eef54544db2d798ea)) { $__slotsStack330cf3602d1fc81eef54544db2d798ea[] = $__slots330cf3602d1fc81eef54544db2d798ea; } ?>
<?php if (isset($__attrs330cf3602d1fc81eef54544db2d798ea)) { $__attrsStack330cf3602d1fc81eef54544db2d798ea[] = $__attrs330cf3602d1fc81eef54544db2d798ea; } ?>
<?php $__attrs330cf3602d1fc81eef54544db2d798ea = ['attributes' => $descriptionAttributes]; ?>
<?php $__slots330cf3602d1fc81eef54544db2d798ea = []; ?>
<?php $__blaze->pushData($__attrs330cf3602d1fc81eef54544db2d798ea); ?>
<?php ob_start(); ?><?php echo e($description); ?><?php $__slots330cf3602d1fc81eef54544db2d798ea['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots330cf3602d1fc81eef54544db2d798ea); ?>
<?php __330cf3602d1fc81eef54544db2d798ea($__blaze, $__attrs330cf3602d1fc81eef54544db2d798ea, $__slots330cf3602d1fc81eef54544db2d798ea, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack330cf3602d1fc81eef54544db2d798ea)) { $__slots330cf3602d1fc81eef54544db2d798ea = array_pop($__slotsStack330cf3602d1fc81eef54544db2d798ea); } ?>
<?php if (! empty($__attrsStack330cf3602d1fc81eef54544db2d798ea)) { $__attrs330cf3602d1fc81eef54544db2d798ea = array_pop($__attrsStack330cf3602d1fc81eef54544db2d798ea); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php echo e($slot); ?>


        
        [STARTCOMPILEDUNBLAZE:4hhar5m543]<?php \Livewire\Blaze\Unblaze::storeScope("4hhar5m543", scope: ['attributes' => $errorAttributes->getAttributes()]) ?><?php \Livewire\Blaze\Unblaze::storeReplacement("4hhar5m543", "CiAgICAgICAgPGZsdXg6ZXJyb3IgOmF0dHJpYnV0ZXM9Im5ldyBcSWxsdW1pbmF0ZVxWaWV3XENvbXBvbmVudEF0dHJpYnV0ZUJhZygkc2NvcGVbJ2F0dHJpYnV0ZXMnXSkiIC8+CiAgICAgICAg") ?>[ENDCOMPILEDUNBLAZE:4hhar5m543]

        <?php if (isset($descriptionTrailing)): ?>
            <?php if (!function_exists('__330cf3602d1fc81eef54544db2d798ea')) { $__blaze->compile('C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/330cf3602d1fc81eef54544db2d798ea.php'); require $__blaze->compiledPath.'/330cf3602d1fc81eef54544db2d798ea.php'; } ?>
<?php if (isset($__slots330cf3602d1fc81eef54544db2d798ea)) { $__slotsStack330cf3602d1fc81eef54544db2d798ea[] = $__slots330cf3602d1fc81eef54544db2d798ea; } ?>
<?php if (isset($__attrs330cf3602d1fc81eef54544db2d798ea)) { $__attrsStack330cf3602d1fc81eef54544db2d798ea[] = $__attrs330cf3602d1fc81eef54544db2d798ea; } ?>
<?php $__attrs330cf3602d1fc81eef54544db2d798ea = ['attributes' => $descriptionAttributes]; ?>
<?php $__slots330cf3602d1fc81eef54544db2d798ea = []; ?>
<?php $__blaze->pushData($__attrs330cf3602d1fc81eef54544db2d798ea); ?>
<?php ob_start(); ?><?php echo e($descriptionTrailing); ?><?php $__slots330cf3602d1fc81eef54544db2d798ea['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots330cf3602d1fc81eef54544db2d798ea); ?>
<?php __330cf3602d1fc81eef54544db2d798ea($__blaze, $__attrs330cf3602d1fc81eef54544db2d798ea, $__slots330cf3602d1fc81eef54544db2d798ea, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack330cf3602d1fc81eef54544db2d798ea)) { $__slots330cf3602d1fc81eef54544db2d798ea = array_pop($__slotsStack330cf3602d1fc81eef54544db2d798ea); } ?>
<?php if (! empty($__attrsStack330cf3602d1fc81eef54544db2d798ea)) { $__attrs330cf3602d1fc81eef54544db2d798ea = array_pop($__attrsStack330cf3602d1fc81eef54544db2d798ea); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    <?php $__slots61bc920947117f631858e73d93440bff['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots61bc920947117f631858e73d93440bff); ?>
<?php __61bc920947117f631858e73d93440bff($__blaze, $__attrs61bc920947117f631858e73d93440bff, $__slots61bc920947117f631858e73d93440bff, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack61bc920947117f631858e73d93440bff)) { $__slots61bc920947117f631858e73d93440bff = array_pop($__slotsStack61bc920947117f631858e73d93440bff); } ?>
<?php if (! empty($__attrsStack61bc920947117f631858e73d93440bff)) { $__attrs61bc920947117f631858e73d93440bff = array_pop($__attrsStack61bc920947117f631858e73d93440bff); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/with-field.blade.php ENDPATH**/ ?>