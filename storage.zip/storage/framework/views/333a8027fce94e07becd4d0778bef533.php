<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    public function mount(): void
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    #[\Livewire\Attributes\Computed()]
    public function application()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('application'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function visibleAnnouncements()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('visibleAnnouncements'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function announcements()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('announcements'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function unreadAnnouncementCount()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('unreadAnnouncementCount'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function upcomingDeadlines()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('upcomingDeadlines'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function nextClassBatch()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('nextClassBatch'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function studentStatus()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('studentStatus'))->execute(...$arguments);
    }

    public function markAnnouncementRead(int $announcementId): void
    {
        $arguments = [static::$__context, $this, func_get_args()];

        (new Actions\CallMethod('markAnnouncementRead'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function documents()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('documents'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function competencyUnits()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('competencyUnits'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function competencySummary()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('competencySummary'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function attendanceRecords()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('attendanceRecords'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function attendanceSummary()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('attendanceSummary'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function trainingCertificate()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('trainingCertificate'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function certificateEligibility()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('certificateEligibility'))->execute(...$arguments);
    }

};