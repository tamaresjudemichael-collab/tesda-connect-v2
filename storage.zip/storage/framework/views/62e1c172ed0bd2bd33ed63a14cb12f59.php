<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::text}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/text.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::text}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/text.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::text}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/text.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::text}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/text.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::text}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/text.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::text}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/text.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::text}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/text.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::text}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/text.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1790619293} ?>
<?php # [BlazeFolded]:{flux::card}:{C:\xampp\htdocs\tesda-connect-v2\vendor\livewire\flux\src/../stubs/resources/views/flux/card/index.blade.php}:{1790619293} ?>
<?php

use App\Models\ActivityLog;
use App\Models\EnrollmentApplication;
use App\Models\Institution;
use App\Models\TrainingBatch;
use App\Models\TrainingCertificate;
use App\Models\User;
use App\Support\InstitutionScope;
use Flux\Flux;

?>

<?php ($data = $this->dashboard); ?>

<div class="mx-auto max-w-7xl space-y-6">
    <a data-user-guide-card href="<?php echo e(route('user-guide')); ?>" wire:navigate class="group relative block overflow-hidden rounded-2xl bg-gradient-to-r from-[#102f68] via-[#174b83] to-cyan-700 p-5 text-white shadow-md transition hover:-translate-y-0.5 hover:shadow-lg sm:p-6">
        <div class="pointer-events-none absolute -right-6 -top-12 h-40 w-40 rounded-full border-[20px] border-white/10"></div>
        <div class="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div class="flex items-start gap-4">
                <span class="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-amber-400 text-2xl font-black text-[#102f68]">?</span>
                <span>
                    <span class="block text-xs font-bold uppercase tracking-[0.18em] text-cyan-100">New here? Start here.</span>
                    <span class="mt-1 block text-xl font-black">User Guide & Role Handbook</span>
                    <span class="mt-1 block max-w-2xl text-sm leading-6 text-blue-100">Learn what your role can do, follow the right workflow, and find answers to common questions.</span>
                </span>
            </div>
            <span class="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-white px-4 py-3 text-sm font-extrabold text-[#102f68] transition group-hover:bg-amber-300">Open User Guide <span aria-hidden="true">â†’</span></span>
        </div>
    </a>
    <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
            <p class="text-sm font-semibold text-cyan-600">TESDAConnect workspace</p>
            <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-2xl [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2 mt-1 text-3xl font-black tracking-tight" data-flux-heading><?php ob_start(); ?>Good day, <?php echo e(auth()->user()->name); ?>.<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><p class="[:where(&amp;)]:font-normal [:where(&amp;)]:text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 mt-1 text-base text-slate-500" data-flux-text ><?php ob_start(); ?>Here is your live overview of TESDA training operations.<?php echo trim(ob_get_clean()); ?></p><?php echo ltrim(ob_get_clean()); ?>
        </div>
        <div class="flex gap-2">
            <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-3 pe-4 inline-flex  bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-800 dark:text-white    *:transition-opacity [&amp;[data-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-flux-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-loading]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[data-flux-loading]&gt;[data-flux-loading-indicator]]:opacity-100 data-loading:pointer-events-none data-flux-loading:pointer-events-none" data-flux-button="data-flux-button" wire:target="refresh" wire:loading.attr="data-flux-loading" wire:click="refresh">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
                    <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M13.836 2.477a.75.75 0 0 1 .75.75v3.182a.75.75 0 0 1-.75.75h-3.182a.75.75 0 0 1 0-1.5h1.37l-.84-.841a4.5 4.5 0 0 0-7.08.932.75.75 0 0 1-1.3-.75 6 6 0 0 1 9.44-1.242l.842.84V3.227a.75.75 0 0 1 .75-.75Zm-.911 7.5A.75.75 0 0 1 13.199 11a6 6 0 0 1-9.44 1.241l-.84-.84v1.371a.75.75 0 0 1-1.5 0V9.591a.75.75 0 0 1 .75-.75H5.35a.75.75 0 0 1 0 1.5H3.98l.841.841a4.5 4.5 0 0 0 7.08-.932.75.75 0 0 1 1.025-.273Z" clip-rule="evenodd"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>Refresh data<?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->hasRole('administrator', 'registrar')): ?>
                <?php ob_start(); ?><a href="<?php echo e(route('enrollments.index')); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-3 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[1px]! [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)]" data-flux-group-target="data-flux-group-target" wire:navigate="">
        <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M11.986 3H12a2 2 0 0 1 2 2v6a2 2 0 0 1-1.5 1.937V7A2.5 2.5 0 0 0 10 4.5H4.063A2 2 0 0 1 6 3h.014A2.25 2.25 0 0 1 8.25 1h1.5a2.25 2.25 0 0 1 2.236 2ZM10.5 4v-.75a.75.75 0 0 0-.75-.75h-1.5a.75.75 0 0 0-.75.75V4h3Z" clip-rule="evenodd"/>
  <path fill-rule="evenodd" d="M3 6a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1H3Zm1.75 2.5a.75.75 0 0 0 0 1.5h3.5a.75.75 0 0 0 0-1.5h-3.5ZM4 11.75a.75.75 0 0 1 .75-.75h3.5a.75.75 0 0 1 0 1.5h-3.5a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>View records<?php echo trim(ob_get_clean()); ?></span>
    </a>
<?php echo ltrim(ob_get_clean()); ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->hasRole('registrar')): ?>
        <section id="recent-submissions" class="space-y-4 scroll-mt-20" aria-labelledby="recent-submissions-heading">
            <div class="flex flex-wrap items-end justify-between gap-3"><div><?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" id="recent-submissions-heading" data-flux-heading><?php ob_start(); ?>Recent Submissions<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?><?php ob_start(); ?><p class="[:where(&amp;)]:font-normal [:where(&amp;)]:text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 mt-1" data-flux-text ><?php ob_start(); ?>The newest 15 submitted enrollment records across your assigned institutions.<?php echo trim(ob_get_clean()); ?></p><?php echo ltrim(ob_get_clean()); ?></div><div class="flex gap-2"><?php ob_start(); ?><a href="<?php echo e(route('registrar.account-requests')); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-4 pe-4 inline-flex  bg-white hover:bg-zinc-50 dark:bg-zinc-700 dark:hover:bg-zinc-600/75 text-zinc-800 dark:text-white border border-zinc-200 hover:border-zinc-200 disabled:border-zinc-200 border-b-zinc-300/80 dark:border-zinc-600 dark:hover:border-zinc-600 dark:disabled:border-zinc-600 shadow-xs [[data-flux-button-group]_&amp;]:border-s-0 [:is([data-flux-button-group]&gt;&amp;:first-child,_[data-flux-button-group]_:first-child&gt;&amp;)]:border-s-[1px]" data-flux-group-target="data-flux-group-target" wire:navigate="">
        <?php ob_start(); ?>Account requests (<?php echo e($data['pending_account_requests']); ?>)<?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?><?php ob_start(); ?><a href="<?php echo e(route('enrollments.index', ['status' => 'submitted'])); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-4 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[1px]! [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)]" data-flux-group-target="data-flux-group-target" wire:navigate="">
        <?php ob_start(); ?>Review enrollments<?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?></div></div>
            <?php ob_start(); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 bg-white p-0 shadow-sm" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?><div class="overflow-x-auto"><table class="w-full min-w-[800px] text-left text-sm"><thead class="bg-slate-50 text-xs uppercase text-slate-500"><tr><th class="px-5 py-3">Applicant</th><th class="px-5 py-3">Course</th><th class="px-5 py-3">Institution / Batch</th><th class="px-5 py-3">Submitted</th><th class="px-5 py-3">Status</th></tr></thead><tbody class="divide-y divide-slate-100"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $data['recent_submissions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'recent-submission-'.e($submission->id).''; ?>wire:key="recent-submission-<?php echo e($submission->id); ?>"><td class="px-5 py-4"><p class="font-semibold text-slate-900"><?php echo e($submission->learner_name); ?></p><p class="text-xs text-slate-500"><?php echo e($submission->reference_no); ?></p></td><td class="px-5 py-4"><?php echo e($submission->course?->name ?? 'Course pending'); ?></td><td class="px-5 py-4"><?php echo e($submission->institution?->code); ?><p class="mt-1 text-xs text-slate-500"><?php echo e($submission->trainingBatch?->name ?? 'Unassigned'); ?></p></td><td class="px-5 py-4"><?php echo e($submission->submitted_at?->format('M j, Y g:i A')); ?></td><td class="px-5 py-4"><span class="rounded-full bg-amber-50 px-2.5 py-1 text-xs font-bold text-amber-800"><?php echo e(str($submission->application_status)->headline()); ?></span></td></tr><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?><tr><td colspan="5" class="px-5 py-10 text-center text-slate-500">No submitted applications yet.</td></tr><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></tbody></table></div><?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
        </section>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($data['focal_overview']): ?>
        <section class="space-y-5" aria-labelledby="focal-overview-heading">
            <div class="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                <div>
                    <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" id="focal-overview-heading" data-flux-heading><?php ob_start(); ?>UTPRAS / Focal Person Overview<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
                    <?php ob_start(); ?><p class="[:where(&amp;)]:font-normal [:where(&amp;)]:text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 mt-1" data-flux-text ><?php ob_start(); ?>Live operations across your assigned institution(s).<?php echo trim(ob_get_clean()); ?></p><?php echo ltrim(ob_get_clean()); ?>
                </div>
                <div class="flex flex-wrap gap-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $data['focal_overview']['assigned_institutions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignedInstitution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <span class="rounded-full border border-cyan-200 bg-cyan-50 px-3 py-1.5 text-xs font-bold text-cyan-800" <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'focal-institution-'.e($assignedInstitution->id).''; ?>wire:key="focal-institution-<?php echo e($assignedInstitution->id); ?>">
                            <?php echo e($assignedInstitution->code); ?> · <?php echo e($assignedInstitution->name); ?>

                        </span>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($data['focal_overview']['assigned_institutions']->isEmpty()): ?>
                        <span class="rounded-full border border-amber-200 bg-amber-50 px-3 py-1.5 text-xs font-bold text-amber-800">No institution assigned</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
            <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [
                    ['Confirmed trainees', $data['focal_overview']['confirmed_trainees'], 'Confirmed student records', 'border-l-[#173b78]'],
                    ['Pending encodings', $data['focal_overview']['pending_encodings'], 'Confirmed trainees with no competency status saved yet', 'border-l-amber-500'],
                    ['Progress summaries pending', $data['focal_overview']['pending_tesda_reports'], 'Confirmed trainee reports not yet marked submitted', 'border-l-cyan-600'],
                    ['Ready for scheduling', $data['focal_overview']['ready_for_scheduling']->count(), 'Confirmed trainees without a batch', 'border-l-emerald-500'],
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $detail, $border]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php ob_start(); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 border-l-4 <?php echo e($border); ?> bg-white p-5 shadow-sm" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?>
                        <p class="text-sm font-semibold text-slate-600"><?php echo e($label); ?></p>
                        <p class="mt-2 text-3xl font-black text-[#102f68]"><?php echo e($value); ?></p>
                        <p class="mt-1 text-xs text-slate-500"><?php echo e($detail); ?></p>
                    <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
            <div class="grid gap-5 xl:grid-cols-2">
                <?php ob_start(); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 bg-white p-0 shadow-sm" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?>
                    <div class="flex items-start justify-between gap-3 border-b border-slate-100 p-5"><div><?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-sm [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Recent enrollments ready for scheduling<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?><?php ob_start(); ?><p class="[:where(&amp;)]:font-normal [:where(&amp;)]:text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 mt-1" data-flux-text ><?php ob_start(); ?>Confirmed trainees that have not yet been assigned to a batch.<?php echo trim(ob_get_clean()); ?></p><?php echo ltrim(ob_get_clean()); ?></div><?php ob_start(); ?><a href="<?php echo e(route('schedules.index')); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-8 text-sm rounded-md gap-2 ps-3 pe-3 inline-flex  bg-white hover:bg-zinc-50 dark:bg-zinc-700 dark:hover:bg-zinc-600/75 text-zinc-800 dark:text-white border border-zinc-200 hover:border-zinc-200 disabled:border-zinc-200 border-b-zinc-300/80 dark:border-zinc-600 dark:hover:border-zinc-600 dark:disabled:border-zinc-600 shadow-xs [[data-flux-button-group]_&amp;]:border-s-0 [:is([data-flux-button-group]&gt;&amp;:first-child,_[data-flux-button-group]_:first-child&gt;&amp;)]:border-s-[1px]" data-flux-group-target="data-flux-group-target" wire:navigate="">
        <?php ob_start(); ?>Open Scheduling<?php echo trim(ob_get_clean()); ?>

    </a>
<?php echo ltrim(ob_get_clean()); ?></div>
                    <div class="overflow-x-auto"><table class="w-full min-w-[520px] text-left text-sm"><thead class="bg-slate-50 text-xs uppercase text-slate-500"><tr><th class="px-4 py-3">Trainee</th><th class="px-4 py-3">Course</th><th class="px-4 py-3">Institution</th><th class="px-4 py-3">Confirmed</th></tr></thead><tbody class="divide-y divide-slate-100">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $data['focal_overview']['ready_for_scheduling']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $readyApplication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'ready-scheduling-'.e($readyApplication->id).''; ?>wire:key="ready-scheduling-<?php echo e($readyApplication->id); ?>"><td class="px-4 py-3"><p class="font-semibold text-slate-900"><?php echo e($readyApplication->learner_name); ?></p><p class="text-xs text-slate-500"><?php echo e($readyApplication->scholar_id ?: $readyApplication->reference_no); ?></p></td><td class="px-4 py-3"><?php echo e($readyApplication->course?->name ?? 'Course pending'); ?></td><td class="px-4 py-3"><?php echo e($readyApplication->institution?->code); ?></td><td class="px-4 py-3"><?php echo e($readyApplication->confirmed_at?->format('M j, Y') ?? '—'); ?></td></tr><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?><tr><td colspan="4" class="px-4 py-8 text-center text-slate-500">No confirmed trainees are waiting for batch assignment.</td></tr><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody></table></div>
                <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
                <?php ob_start(); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 bg-white p-0 shadow-sm" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?>
                    <div class="border-b border-slate-100 p-5"><?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-sm [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Upcoming batch end dates<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?><?php ob_start(); ?><p class="[:where(&amp;)]:font-normal [:where(&amp;)]:text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 mt-1" data-flux-text ><?php ob_start(); ?>Use these dates to prepare TESDA reports and completion checks. Explicit report due dates are not stored in this version.<?php echo trim(ob_get_clean()); ?></p><?php echo ltrim(ob_get_clean()); ?></div>
                    <div class="divide-y divide-slate-100">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $data['focal_overview']['upcoming_deadlines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deadlineBatch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><div class="flex items-start justify-between gap-3 p-4"><div><p class="font-semibold text-slate-900"><?php echo e($deadlineBatch->name); ?></p><p class="text-xs text-slate-500"><?php echo e($deadlineBatch->institution?->code); ?> · <?php echo e($deadlineBatch->course?->name); ?></p></div><span class="shrink-0 rounded-lg bg-amber-50 px-2.5 py-1.5 text-xs font-bold text-amber-800">Ends <?php echo e($deadlineBatch->ends_at?->format('M j, Y')); ?></span></div><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?><div class="p-8 text-center text-sm text-slate-500">No batch end dates are due within the next 30 days.</div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
            </div>
        </section>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($data['administrator_overview']): ?>
        <section class="space-y-5" aria-labelledby="system-overview-heading">
            <div>
                <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" id="system-overview-heading" data-flux-heading><?php ob_start(); ?>System overview<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
                <?php ob_start(); ?><p class="[:where(&amp;)]:font-normal [:where(&amp;)]:text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 mt-1" data-flux-text ><?php ob_start(); ?>Administrator quick stats across BST and MIF.<?php echo trim(ob_get_clean()); ?></p><?php echo ltrim(ob_get_clean()); ?>
            </div>
            <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [
                    ['Active users', $data['administrator_overview']['active_users'], 'Accounts with Active status'],
                    ['Confirmed enrollees', $data['administrator_overview']['confirmed_enrollees'], 'Enrollment applications confirmed'],
                    ['Pending tasks', $data['administrator_overview']['pending_tasks'], 'Submitted, under review, or returned'],
                    ["This month’s intake", $data['administrator_overview']['this_month_intake'], 'Applications submitted this month'],
                    ['Pending verifications', $data['administrator_overview']['pending_verifications'], 'Submitted or forwarded for review'],
                    ['Schedule deadlines', $data['administrator_overview']['upcoming_schedule_deadlines'], 'Batch end dates within the next 30 days'],
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $detail]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php ob_start(); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 border border-slate-200 bg-white p-5 shadow-sm" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?>
                        <p class="text-sm font-semibold text-slate-600"><?php echo e($label); ?></p>
                        <p class="mt-2 text-3xl font-black tracking-tight text-[#102f68]"><?php echo e($value); ?></p>
                        <p class="mt-1 text-xs text-slate-400"><?php echo e($detail); ?></p>
                    <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>

            <div>
                <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>BST vs MIF comparison<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
                <?php ob_start(); ?><p class="[:where(&amp;)]:font-normal [:where(&amp;)]:text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 mt-1" data-flux-text ><?php ob_start(); ?>Enrollment records, monthly intake, pending work, and completion rate.<?php echo trim(ob_get_clean()); ?></p><?php echo ltrim(ob_get_clean()); ?>
            </div>
            <div class="grid gap-4 lg:grid-cols-2">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [['code' => 'BST', 'tone' => 'blue'], ['code' => 'MIF', 'tone' => 'emerald']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institutionView): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php ($institutionStats = $data['administrator_overview']['comparison'][$institutionView['code']]); ?>
                    <?php ob_start(); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 border-t-4 <?php echo e($institutionView['tone'] === 'blue' ? 'border-t-blue-600' : 'border-t-emerald-600'); ?> bg-white p-5 shadow-sm" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?>
                        <div class="flex items-start justify-between gap-3">
                            <div>
                                <p class="text-xs font-bold uppercase tracking-widest <?php echo e($institutionView['tone'] === 'blue' ? 'text-blue-700' : 'text-emerald-700'); ?>"><?php echo e($institutionView['code']); ?></p>
                                <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-sm [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2 mt-1" data-flux-heading><?php ob_start(); ?><?php echo e($institutionStats['name']); ?><?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
                            </div>
                            <span class="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600"><?php echo e($institutionStats['completion_rate']); ?>% complete</span>
                        </div>
                        <dl class="mt-5 grid grid-cols-2 gap-3">
                            <div class="rounded-xl bg-slate-50 p-3"><dt class="text-xs text-slate-500">Enrollment records</dt><dd class="mt-1 text-2xl font-black text-slate-800"><?php echo e($institutionStats['enrollment_records']); ?></dd></div>
                            <div class="rounded-xl bg-slate-50 p-3"><dt class="text-xs text-slate-500">This month’s intake</dt><dd class="mt-1 text-2xl font-black text-slate-800"><?php echo e($institutionStats['monthly_intake']); ?></dd></div>
                            <div class="rounded-xl bg-slate-50 p-3"><dt class="text-xs text-slate-500">Pending applications</dt><dd class="mt-1 text-2xl font-black text-slate-800"><?php echo e($institutionStats['pending']); ?></dd></div>
                            <div class="rounded-xl bg-slate-50 p-3"><dt class="text-xs text-slate-500">Confirmed enrollees</dt><dd class="mt-1 text-2xl font-black text-slate-800"><?php echo e($institutionStats['confirmed']); ?></dd></div>
                        </dl>
                        <div class="mt-4 h-2 overflow-hidden rounded-full bg-slate-100"><div class="h-full rounded-full <?php echo e($institutionView['tone'] === 'blue' ? 'bg-blue-600' : 'bg-emerald-600'); ?>" style="width: <?php echo e($institutionStats['completion_rate']); ?>%"></div></div>
                        <p class="mt-2 text-xs text-slate-400">Completion rate = completed certificates ÷ confirmed enrollees.</p>
                    <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </section>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [
            ['Total Trainees', $data['total_trainees'], 'Active learner records', 'border-l-[#173b78]', '♟'],
            ['Pending Intake Forms', $data['pending_intakes'], 'Needs staff review', 'border-l-amber-500', '▤'],
            ['Incomplete Records', $data['incomplete_records'], 'Documents or fields missing', 'border-l-rose-500', '⚠'],
            ['Upcoming Batches', $data['upcoming_batches'], 'Ready for coordination', 'border-l-emerald-500', '□'],
            ['Report Readiness', $data['readiness'].'%', 'Based on complete records', 'border-l-cyan-500', '◴'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $detail, $border, $icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php ob_start(); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 border-l-4 <?php echo e($border); ?> bg-white p-5 shadow-sm" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?>
                <span class="grid size-10 place-items-center rounded-xl bg-slate-50 text-lg text-slate-500"><?php echo e($icon); ?></span>
                <p class="mt-4 text-4xl font-black tracking-tight text-[#102f68]"><?php echo e($value); ?></p>
                <p class="mt-1 text-sm font-semibold text-slate-700"><?php echo e($label); ?></p>
                <p class="mt-2 text-xs text-slate-400"><?php echo e($detail); ?></p>
            <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>

    <div class="grid gap-6 xl:grid-cols-[minmax(0,1.8fr)_minmax(20rem,.85fr)]">
        <?php ob_start(); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 bg-white p-6 shadow-sm" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?>
            <div class="flex items-center justify-between"><div><?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Trainee enrollment per batch<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?><?php ob_start(); ?><p class="[:where(&amp;)]:font-normal [:where(&amp;)]:text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 mt-1" data-flux-text ><?php ob_start(); ?>Current records assigned to each training batch<?php echo trim(ob_get_clean()); ?></p><?php echo ltrim(ob_get_clean()); ?></div><span class="rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700">Live data</span></div>
            <div class="mt-8 flex h-64 items-end gap-3 border-b border-slate-100 px-2 pb-7">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $data['batches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php ($enrolled = $batch->applications()->count()); ?>
                    <?php ($height = max(12, min(100, $batch->capacity ? ($enrolled / $batch->capacity) * 100 : 0))); ?>
                    <div class="flex min-w-0 flex-1 flex-col items-center gap-2"><span class="text-sm font-bold text-slate-600"><?php echo e($enrolled); ?></span><div class="w-full max-w-16 rounded-t-xl bg-gradient-to-t from-[#173b78] to-cyan-500 transition-all" style="height: <?php echo e($height); ?>%"></div><span class="truncate text-center text-xs text-slate-500"><?php echo e($batch->name); ?></span></div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <div class="grid h-full w-full place-items-center text-sm text-slate-400">No batches have been created yet.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>

        <?php ob_start(); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 bg-white p-6 shadow-sm" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?>
            <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Record completeness<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
            <div class="mt-7 grid place-items-center"><div class="grid size-48 place-items-center rounded-full" style="background: conic-gradient(#22c55e <?php echo e($data['readiness']); ?>%, #fee2e2 0)"><div class="grid size-32 place-items-center rounded-full bg-white text-center"><span class="text-4xl font-black text-[#102f68]"><?php echo e($data['readiness']); ?>%</span><span class="-mt-5 text-xs text-slate-400">complete</span></div></div></div>
            <div class="mt-7 grid grid-cols-2 gap-3 text-sm"><div class="rounded-xl bg-emerald-50 p-3"><p class="font-bold text-emerald-700">Complete</p><p class="mt-1 text-xs text-emerald-600">Ready for reports</p></div><div class="rounded-xl bg-rose-50 p-3"><p class="font-bold text-rose-700">Action needed</p><p class="mt-1 text-xs text-rose-600">Complete missing data</p></div></div>
        <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
    </div>

    <div class="grid gap-6 xl:grid-cols-[1fr_1fr]">
        <?php ob_start(); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 bg-white p-6 shadow-sm" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?>
            <div class="flex items-center justify-between"><?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Recent activity<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?><a href="<?php echo e(auth()->user()->hasRole('administrator') ? route('system.activity') : route('reports.index')); ?>" class="text-sm font-semibold text-blue-700" wire:navigate>View all</a></div>
            <div class="mt-4 divide-y divide-slate-100">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $data['activities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="flex gap-3 py-4"><span class="mt-0.5 grid size-8 place-items-center rounded-full bg-blue-50 text-sm">●</span><div><p class="text-sm font-semibold text-slate-700"><?php echo e($activity->description); ?></p><p class="mt-1 text-xs text-slate-400"><?php echo e($activity->created_at->diffForHumans()); ?></p></div></div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <p class="py-8 text-center text-sm text-slate-400">No activity has been logged yet.</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>

        <?php ob_start(); ?><div
    class="border bg-clip-padding dark:bg-clip-border [:where(&amp;)]:border-zinc-900/10 dark:[:where(&amp;)]:border-white/10 [:where(&amp;)]:shadow-xs dark:[:where(&amp;)]:shadow-none relative after:pointer-events-none after:absolute after:inset-0 after:rounded-[calc(var(--flux-card-radius)-1px)] after:inset-ring [:where(&amp;)]:after:inset-ring-white/25 dark:after:hidden after:[mask-image:linear-gradient(to_bottom,black,transparent)] [:where(&amp;)]:bg-white dark:[:where(&amp;)]:bg-white/10 bg-white p-6 shadow-sm" data-flux-card-body-variant="seamless" data-flux-card-variant="default"
    data-flux-card
>
    <?php ob_start(); ?>
            <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Quick actions<?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
            <div class="mt-5 grid gap-3 sm:grid-cols-2">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->hasRole('administrator', 'registrar')): ?>
                    <?php ob_start(); ?><a href="<?php echo e(route('enrollments.index')); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-3 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[1px]! [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)]" data-flux-group-target="data-flux-group-target" wire:navigate="">
        <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path d="M8.5 4.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0ZM10 13c.552 0 1.01-.452.9-.994a5.002 5.002 0 0 0-9.802 0c-.109.542.35.994.902.994h8ZM12.5 3.5a.75.75 0 0 1 .75.75v1h1a.75.75 0 0 1 0 1.5h-1v1a.75.75 0 0 1-1.5 0v-1h-1a.75.75 0 0 1 0-1.5h1v-1a.75.75 0 0 1 .75-.75Z"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>Review intake<?php echo trim(ob_get_clean()); ?></span>
    </a>
<?php echo ltrim(ob_get_clean()); ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->hasRole('administrator', 'registrar', 'focal_person')): ?>
                    <?php ob_start(); ?><a href="<?php echo e(route('schedules.index')); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-3 pe-4 inline-flex  bg-zinc-800/5 hover:bg-zinc-800/10 dark:bg-white/10 dark:hover:bg-white/20 text-zinc-800 dark:text-white   [[data-flux-button-group]_&amp;]:border-e [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [[data-flux-button-group]_&amp;]:border-zinc-200/80 dark:[[data-flux-button-group]_&amp;]:border-zinc-900/50" data-flux-group-target="data-flux-group-target" wire:navigate="">
        <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path d="M5.75 7.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5ZM5 10.25a.75.75 0 1 1 1.5 0 .75.75 0 0 1-1.5 0ZM10.25 7.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5ZM7.25 8.25a.75.75 0 1 1 1.5 0 .75.75 0 0 1-1.5 0ZM8 9.5A.75.75 0 1 0 8 11a.75.75 0 0 0 0-1.5Z"/>
  <path fill-rule="evenodd" d="M4.75 1a.75.75 0 0 0-.75.75V3a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2V1.75a.75.75 0 0 0-1.5 0V3h-5V1.75A.75.75 0 0 0 4.75 1ZM3.5 7a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v4.5a1 1 0 0 1-1 1h-7a1 1 0 0 1-1-1V7Z" clip-rule="evenodd"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>Manage schedules<?php echo trim(ob_get_clean()); ?></span>
    </a>
<?php echo ltrim(ob_get_clean()); ?>
                    <?php ob_start(); ?><a href="<?php echo e(route('reports.index')); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-3 pe-4 inline-flex  bg-zinc-800/5 hover:bg-zinc-800/10 dark:bg-white/10 dark:hover:bg-white/20 text-zinc-800 dark:text-white   [[data-flux-button-group]_&amp;]:border-e [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [[data-flux-button-group]_&amp;]:border-zinc-200/80 dark:[[data-flux-button-group]_&amp;]:border-zinc-900/50" data-flux-group-target="data-flux-group-target" wire:navigate="">
        <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path d="M12 2a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1h-1ZM6.5 6a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1V6ZM2 9a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V9Z"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>Open reports<?php echo trim(ob_get_clean()); ?></span>
    </a>
<?php echo ltrim(ob_get_clean()); ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->hasRole('scholar')): ?>
                    <?php ob_start(); ?><a href="<?php echo e(route('learner.portal')); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center whitespace-nowrap disabled:opacity-50 dark:disabled:opacity-50 disabled:cursor-default disabled:pointer-events-none disabled:shadow-none justify-center h-10 text-sm rounded-lg gap-2 ps-3 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[1px]! [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)]" data-flux-group-target="data-flux-group-target" wire:navigate="">
        <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path d="M7.702 1.368a.75.75 0 0 1 .597 0c2.098.91 4.105 1.99 6.004 3.223a.75.75 0 0 1-.194 1.348A34.27 34.27 0 0 0 8.341 8.25a.75.75 0 0 1-.682 0c-.625-.32-1.262-.62-1.909-.901v-.542a36.878 36.878 0 0 1 2.568-1.33.75.75 0 0 0-.636-1.357 38.39 38.39 0 0 0-3.06 1.605.75.75 0 0 0-.372.648v.365c-.773-.294-1.56-.56-2.359-.8a.75.75 0 0 1-.194-1.347 40.901 40.901 0 0 1 6.005-3.223ZM4.25 8.348c-.53-.212-1.067-.411-1.611-.596a40.973 40.973 0 0 0-.418 2.97.75.75 0 0 0 .474.776c.175.068.35.138.524.21a5.544 5.544 0 0 1-.58.681.75.75 0 1 0 1.06 1.06c.35-.349.655-.726.915-1.124a29.282 29.282 0 0 0-1.395-.617A5.483 5.483 0 0 0 4.25 8.5v-.152Z"/>
  <path d="M7.603 13.96c-.96-.6-1.958-1.147-2.989-1.635a6.981 6.981 0 0 0 1.12-3.341c.419.192.834.393 1.244.602a2.25 2.25 0 0 0 2.045 0 32.787 32.787 0 0 1 4.338-1.834c.175.978.315 1.969.419 2.97a.75.75 0 0 1-.474.776 29.385 29.385 0 0 0-4.909 2.461.75.75 0 0 1-.794 0Z"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>My learning portal<?php echo trim(ob_get_clean()); ?></span>
    </a>
<?php echo ltrim(ob_get_clean()); ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <div class="mt-8 border-t border-slate-100 pt-5"><p class="text-sm font-bold text-slate-700">Batch status overview</p><div class="mt-4 space-y-4"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $data['batches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><div><div class="mb-1 flex justify-between text-xs"><span class="font-medium text-slate-600"><?php echo e($batch->name); ?></span><span class="font-bold text-slate-500"><?php echo e($batch->status === 'in_training' ? 'In training' : 'Upcoming'); ?></span></div><div class="h-2 overflow-hidden rounded-full bg-slate-100"><div class="h-full rounded-full <?php echo e($batch->status === 'in_training' ? 'bg-emerald-500' : 'bg-amber-500'); ?>" style="width: <?php echo e($batch->status === 'in_training' ? '72' : '35'); ?>%"></div></div></div><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?> <p class="text-sm text-slate-400">No batch data yet.</p><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div></div>
        <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\tesda-connect-v2\resources\views\livewire/dashboard.blade.php ENDPATH**/ ?>